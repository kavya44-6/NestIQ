import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:8089/api',
  timeout: 15000,
})

const STORAGE_KEYS = {
  AGENT:    'nestiq_agent_session',
  CUSTOMER: 'nestiq_customer_session',
  ADMIN:    'nestiq_admin_session',
  OWNER:    'nestiq_owner_session',
}

api.interceptors.request.use(config => {
  try {
    const directToken = localStorage.getItem('token')
    if (directToken) {
      config.headers.Authorization = `Bearer ${directToken}`
    } else {
      const activeRole = sessionStorage.getItem('nestiq_active_role')
      if (activeRole && STORAGE_KEYS[activeRole]) {
        const raw = localStorage.getItem(STORAGE_KEYS[activeRole])
        if (raw) {
          const parsed = JSON.parse(raw)
          if (parsed?.token) {
            config.headers.Authorization = `Bearer ${parsed.token}`
          }
        }
      } else {
        for (const key of Object.values(STORAGE_KEYS)) {
          const raw = localStorage.getItem(key)
          if (raw) {
            const parsed = JSON.parse(raw)
            if (parsed?.token) {
              config.headers.Authorization = `Bearer ${parsed.token}`
              break
            }
          }
        }
      }
    }
  } catch {}
  return config
})

api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k))
      sessionStorage.removeItem('nestiq_active_role')
      window.location.href = '/customer/login'
    }
    return Promise.reject(err)
  }
)

export default api