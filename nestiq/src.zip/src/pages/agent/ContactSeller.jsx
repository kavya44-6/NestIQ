import { useState, useEffect } from 'react'
import DashboardLayout from '../../layouts/DashboardLayout'
import Modal from '../../components/common/Modal'
import {
  sendAgentMessage,
  sendToOwner,
  getMyAgentMessages,
  getOwnerReplies,
} from '../../services/agentMessageService'
import { getMyProperties } from '../../services/propertyService'
import { formatDate } from '../../utils/formatters'

export default function ContactSeller() {
  const [messages,      setMessages]      = useState([])
  const [ownerReplies,  setOwnerReplies]  = useState([])
  const [properties,    setProperties]    = useState([])
  const [loading,       setLoading]       = useState(true)
  const [modalOpen,     setModalOpen]     = useState(false)
  const [submitting,    setSubmitting]    = useState(false)
  const [success,       setSuccess]       = useState('')
  const [tab,           setTab]           = useState('owner') // 'owner' | 'company'

  const [form, setForm] = useState({
    propertyId:  '',
    companyName: '',
    message:     '',
  })

  const fetchAll = () => {
    Promise.all([
      getMyAgentMessages().then(r => setMessages(r.data || [])).catch(() => {}),
      getOwnerReplies().then(r => setOwnerReplies(r.data || [])).catch(() => {}),
      getMyProperties().then(r => setProperties(r.data || [])).catch(() => {}),
    ]).finally(() => setLoading(false))
  }

  useEffect(() => { fetchAll() }, [])

  const selectedProp = properties.find(p => String(p.id) === String(form.propertyId))
  const hasOwner     = selectedProp?.ownerId || selectedProp?.ownerName

  const handlePropertyChange = (e) => {
    const id   = e.target.value
    const prop = properties.find(p => String(p.id) === id)
    setForm(f => ({
      ...f,
      propertyId:  id,
      companyName: prop?.sellerCompany || '',
    }))
  }

  const handleSend = async () => {
    if (!form.propertyId || !form.message.trim()) return
    setSubmitting(true)
    try {
      if (hasOwner) {
        // Send directly to the owner via the owner_messages table
        await sendToOwner({ propertyId: Number(form.propertyId), message: form.message })
        setSuccess('Message sent to Property Owner! You will see their reply here once they respond.')
      } else {
        // Legacy path — send to company name string
        await sendAgentMessage({
          propertyId:  Number(form.propertyId),
          companyName: form.companyName,
          message:     form.message,
        })
        setSuccess('Message sent to property seller!')
      }
      setModalOpen(false)
      setForm({ propertyId: '', companyName: '', message: '' })
      fetchAll()
    } catch {
      setSuccess('error')
    } finally {
      setSubmitting(false)
    }
  }

  const statusClass = s => s === 'REPLIED' ? 'badge-green' : 'badge-gold'

  // Combine owner replies + company messages for display
  const ownerMsgs   = ownerReplies
  const companyMsgs = messages

  return (
    <DashboardLayout>
      <div className="dashboard-header flex-between">
        <div>
          <h2>Contact Seller / Owner</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
            Send messages to property owners or seller companies on behalf of your customers
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setModalOpen(true)}>
          ✉️ New Message
        </button>
      </div>

      {success === 'error' && (
        <div className="alert alert-error" style={{ marginBottom: 16 }}>Something went wrong. Please try again.</div>
      )}
      {success && success !== 'error' && (
        <div className="alert alert-success" style={{ marginBottom: 16 }}>✅ {success}</div>
      )}

      {/* Info banner */}
      <div style={{ background: 'rgba(217, 119, 6, 0.1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '14px 18px', marginBottom: 20, fontSize: 14, color: 'var(--text-secondary)' }}>
        💡 When a property has a registered owner, your message goes directly to them. For properties without a registered owner, it is sent to the seller company name you enter.
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 24, borderBottom: '2px solid var(--border)' }}>
        {[
          { key: 'owner',   label: `📨 Owner Messages (${ownerMsgs.length})` },
          { key: 'company', label: `🏢 Company Messages (${companyMsgs.length})` },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{
              padding: '10px 20px', border: 'none', background: 'transparent',
              fontWeight: tab === t.key ? 700 : 400,
              color: tab === t.key ? 'var(--green-700)' : 'var(--text-muted)',
              borderBottom: tab === t.key ? '2px solid var(--green-600)' : '2px solid transparent',
              cursor: 'pointer', fontSize: 14, marginBottom: -2,
            }}
          >{t.label}</button>
        ))}
      </div>

      {loading ? <div className="loading-page"><div className="spinner" /></div> : (
        <>
          {/* Owner messages tab */}
          {tab === 'owner' && (
            ownerMsgs.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🏡</div>
                <p>No messages to property owners yet.</p>
                <button className="btn btn-primary" onClick={() => setModalOpen(true)}>Send First Message</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {ownerMsgs.map(msg => (
                  <div key={msg.id} style={{ background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)', border: `1px solid ${msg.status === 'PENDING' ? '#fca5a5' : 'var(--border)'}`, padding: 20 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{msg.propertyTitle || `Property #${msg.propertyId}`}</div>
                        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                          To: <strong>{msg.ownerName || 'Property Owner'}</strong> · {formatDate(msg.createdAt)}
                        </div>
                      </div>
                      <span className={`badge ${statusClass(msg.status)}`}>{msg.status}</span>
                    </div>

                    <div style={{ background: 'var(--green-50)', borderRadius: 'var(--radius-md)', padding: '12px 14px', marginBottom: msg.ownerReply ? 12 : 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--green-700)', marginBottom: 4 }}>📤 Your Message</div>
                      <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.agentMessage || msg.message}</p>
                    </div>

                    {msg.ownerReply ? (
                      <div style={{ background: 'rgba(217, 119, 6, 0.1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '12px 14px' }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>🏡 Owner Reply · {formatDate(msg.repliedAt)}</div>
                        <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.ownerReply}</p>
                      </div>
                    ) : (
                      <p style={{ fontSize: 12, color: '#b91c1c', marginTop: 8 }}>⏳ Awaiting reply from owner...</p>
                    )}
                  </div>
                ))}
              </div>
            )
          )}

          {/* Company messages tab */}
          {tab === 'company' && (
            companyMsgs.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📨</div>
                <p>No company messages sent yet.</p>
                <button className="btn btn-primary" onClick={() => setModalOpen(true)}>Send First Message</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {companyMsgs.map(msg => (
                  <div key={msg.id} style={{ background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)', padding: 20 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{msg.propertyTitle || `Property #${msg.propertyId}`}</div>
                        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                          To: <strong>{msg.companyName || 'Property Seller'}</strong> · {formatDate(msg.createdAt)}
                        </div>
                      </div>
                      <span className={`badge ${statusClass(msg.status)}`}>{msg.status}</span>
                    </div>

                    <div style={{ background: 'var(--green-50)', borderRadius: 'var(--radius-md)', padding: '12px 14px', marginBottom: msg.companyReply ? 12 : 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--green-700)', marginBottom: 4 }}>📤 Your Message</div>
                      <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.message}</p>
                    </div>

                    {msg.companyReply ? (
                      <div style={{ background: 'rgba(217, 119, 6, 0.1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '12px 14px' }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>🏢 Seller Reply</div>
                        <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.companyReply}</p>
                      </div>
                    ) : (
                      <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>⏳ Awaiting reply from the seller...</p>
                    )}
                  </div>
                ))}
              </div>
            )
          )}
        </>
      )}

      {/* Compose Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Contact Property Seller / Owner">
        <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 16 }}>
          Select a property. If it has a registered owner, the message will go directly to them.
        </p>

        <div className="form-group">
          <label>Select Property *</label>
          <select value={form.propertyId} onChange={handlePropertyChange}>
            <option value="">Choose a property</option>
            {properties.map(p => (
              <option key={p.id} value={p.id}>{p.title} — {p.city}</option>
            ))}
          </select>
        </div>

        {selectedProp && (
          <div style={{
            background: hasOwner ? 'var(--green-50)' : 'rgba(217, 119, 6, 0.1)',
            border: `1px solid ${hasOwner ? 'var(--green-200)' : 'var(--border)'}`,
            borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: 16, fontSize: 13,
          }}>
            {hasOwner ? (
              <>
                <strong>🏡 Owner:</strong> {selectedProp.ownerName || 'Registered Owner'}
                <div style={{ fontSize: 12, color: 'var(--green-700)', marginTop: 2 }}>Message will be sent directly to this property owner</div>
              </>
            ) : (
              <>
                <strong>🏢 No registered owner.</strong> Message will go to the seller company.
              </>
            )}
          </div>
        )}

        {!hasOwner && (
          <div className="form-group">
            <label>Seller / Company Name</label>
            <input
              value={form.companyName}
              onChange={e => setForm(f => ({ ...f, companyName: e.target.value }))}
              placeholder="e.g. Greenfield Properties Pvt Ltd"
            />
          </div>
        )}

        <div className="form-group">
          <label>Your Message *</label>
          <textarea
            value={form.message}
            onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
            rows={5}
            placeholder="e.g. I have a customer interested in this property. They would like to schedule a visit on 15th June at 11 AM. Please confirm availability..."
          />
        </div>

        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button className="btn btn-outline btn-sm" onClick={() => setModalOpen(false)}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSend}
            disabled={submitting || !form.propertyId || !form.message.trim()}>
            {submitting ? 'Sending...' : hasOwner ? '📨 Send to Owner' : '📨 Send to Seller'}
          </button>
        </div>
      </Modal>
    </DashboardLayout>
  )
}