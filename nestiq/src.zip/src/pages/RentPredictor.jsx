import { useState } from 'react'
import MainLayout from '../layouts/MainLayout'
import { estimatePrice } from '../services/aiService'

const CITIES      = ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tiruppur', 'Vellore']
const FURNISHINGS = ['Unfurnished', 'Semi Furnished', 'Fully Furnished']

function fmt(n) { return '₹' + Number(n).toLocaleString('en-IN') }

export default function RentPredictor() {
  const [city,        setCity]        = useState('')
  const [area,        setArea]        = useState('')
  const [bhk,         setBhk]         = useState('')
  const [listingType, setListingType] = useState('RENT')
  const [furnishing,  setFurnishing]  = useState('Unfurnished')
  const [result,      setResult]      = useState(null)
  const [loading,     setLoading]     = useState(false)
  const [error,       setError]       = useState('')

  const resetResult = () => setResult(null)

  const calculate = async () => {
    setError('')
    setResult(null)

    if (!city)  { setError('Please select a city.'); return }
    if (!area || isNaN(area) || Number(area) <= 0) { setError('Enter a valid area in sqft.'); return }
    if (!bhk)   { setError('Please select BHK.'); return }

    setLoading(true)
    try {
      const data = await estimatePrice({ city, area: Number(area), bhk: Number(bhk), listingType, furnishing })
      setResult(data)
    } catch {
      setError('Could not estimate price. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const isRent = listingType === 'RENT'

  return (
    <MainLayout>
      <div style={{ paddingTop: 'var(--navbar-height)', minHeight: '100vh', background: 'var(--green-50)' }}>

        {/* Hero */}
        <div style={{ background: 'var(--green-900)', padding: '40px 0' }}>
          <div className="container">
            <h1 style={{ color: 'var(--text-on-dark)', fontSize: 28, marginBottom: 4 }}>🔮 Rent & Price Predictor</h1>
            <p style={{ color: 'rgba(232,245,238,0.65)', fontSize: 14 }}>
              AI-powered estimates for rent or sale price based on Tamil Nadu market data
            </p>
          </div>
        </div>

        <div className="container" style={{ padding: '48px 24px' }}>
          <div style={{ maxWidth: 560, margin: '0 auto' }}>

            {/* ── Input card ── */}
            <div style={{
              background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border)', padding: '32px',
              boxShadow: 'var(--shadow-md)',
            }}>
              <h2 style={{ marginBottom: 6 }}>Estimate Your Price</h2>
              <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 28 }}>
                Fill in the details below for an AI-powered estimate
              </p>

              {error && <div className="alert alert-error" style={{ marginBottom: 16 }}>{error}</div>}

              {/* Listing Type toggle */}
              <div className="form-group">
                <label>Listing Type</label>
                <div style={{ display: 'flex', gap: 10 }}>
                  {['RENT', 'SALE'].map(t => (
                    <button
                      key={t} type="button"
                      onClick={() => { setListingType(t); resetResult() }}
                      style={{
                        flex: 1, padding: '11px', borderRadius: 'var(--radius-md)',
                        border: `2px solid ${listingType === t ? 'var(--green-500)' : 'var(--border)'}`,
                        background: listingType === t ? 'var(--green-100)' : 'var(--cream-100)',
                        color: listingType === t ? 'var(--green-700)' : 'var(--text-muted)',
                        fontWeight: listingType === t ? 700 : 400,
                        cursor: 'pointer', transition: 'all 0.2s', fontSize: 14,
                      }}
                    >
                      {t === 'RENT' ? '🏠 For Rent' : '💰 For Sale'}
                    </button>
                  ))}
                </div>
              </div>

              {/* City */}
              <div className="form-group">
                <label>City</label>
                <select value={city} onChange={e => { setCity(e.target.value); resetResult() }}>
                  <option value="">Select a city</option>
                  {CITIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>

              {/* Area */}
              <div className="form-group">
                <label>Area (sqft)</label>
                <input
                  type="number" value={area}
                  onChange={e => { setArea(e.target.value); resetResult() }}
                  placeholder="e.g. 850" min="100" max="10000"
                />
              </div>

              {/* BHK */}
              <div className="form-group">
                <label>BHK Configuration</label>
                <div style={{ display: 'flex', gap: 10 }}>
                  {['1', '2', '3', '4'].map(b => (
                    <button
                      key={b} type="button"
                      onClick={() => { setBhk(b); resetResult() }}
                      style={{
                        flex: 1, padding: '11px', borderRadius: 'var(--radius-md)',
                        border: `2px solid ${bhk === b ? 'var(--green-500)' : 'var(--border)'}`,
                        background: bhk === b ? 'var(--green-100)' : 'var(--cream-100)',
                        color: bhk === b ? 'var(--green-700)' : 'var(--text-muted)',
                        fontWeight: bhk === b ? 700 : 400,
                        cursor: 'pointer', transition: 'all 0.2s', fontSize: 14,
                      }}
                    >
                      {b} BHK
                    </button>
                  ))}
                </div>
              </div>

              {/* Furnishing */}
              <div className="form-group">
                <label>Furnishing</label>
                <select value={furnishing} onChange={e => { setFurnishing(e.target.value); resetResult() }}>
                  {FURNISHINGS.map(f => <option key={f}>{f}</option>)}
                </select>
              </div>

              <button
                onClick={calculate}
                disabled={loading}
                className="btn btn-gold btn-full btn-lg"
                style={{ marginTop: 8 }}
              >
                {loading
                  ? <><span className="spinner spinner-sm" /> Analysing…</>
                  : '🔮 Get AI Estimate'
                }
              </button>
            </div>

            {/* ── Result card ── */}
            {result && (
              <div style={{
                background: 'var(--green-800)', borderRadius: 'var(--radius-lg)',
                padding: '28px 32px', marginTop: 20,
                animation: 'fadeIn 0.35s ease',
              }}>
                {/* Header */}
                <p style={{
                  color: 'rgba(232,245,238,0.7)', fontSize: 12, marginBottom: 6,
                  textTransform: 'uppercase', letterSpacing: '0.6px', fontWeight: 600,
                }}>
                  {isRent ? 'Estimated Monthly Rent' : 'Estimated Sale Price'}
                </p>

                {/* Range */}
                <p style={{ color: 'var(--text-on-dark)', fontSize: 38, fontWeight: 700, marginBottom: 2, letterSpacing: '-0.5px' }}>
                  {fmt(result.estimatedMin)} – {fmt(result.estimatedMax)}
                </p>
                <p style={{ color: 'rgba(232,245,238,0.55)', fontSize: 12, marginBottom: 18 }}>
                  {isRent ? 'per month' : 'total sale price'} · {city} · {area} sqft · {bhk} BHK · {furnishing}
                </p>

                {/* Min / Max breakdown */}
                <div style={{
                  display: 'flex', gap: 12, marginBottom: 18,
                }}>
                  {[
                    { label: 'Conservative',  value: result.estimatedMin, icon: '📉' },
                    { label: 'Optimistic',    value: result.estimatedMax, icon: '📈' },
                  ].map(({ label, value, icon }) => (
                    <div key={label} style={{
                      flex: 1, background: 'rgba(255,255,255,0.08)',
                      borderRadius: 'var(--radius-md)', padding: '12px 14px',
                      textAlign: 'center',
                    }}>
                      <div style={{ fontSize: 18, marginBottom: 4 }}>{icon}</div>
                      <div style={{ color: 'var(--text-on-dark)', fontWeight: 700, fontSize: 16 }}>{fmt(value)}</div>
                      <div style={{ color: 'rgba(232,245,238,0.55)', fontSize: 11, marginTop: 2 }}>{label}</div>
                    </div>
                  ))}
                </div>

                {/* AI Explanation */}
                {result.explanation && (
                  <div style={{
                    background: 'rgba(255,255,255,0.07)',
                    borderRadius: 'var(--radius-md)',
                    padding: '12px 16px',
                    borderLeft: '3px solid var(--gold-300)',
                  }}>
                    <p style={{ color: 'var(--gold-300)', fontSize: 11, fontWeight: 700, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
                      ✨ AI Explanation
                    </p>
                    <p style={{ color: 'rgba(232,245,238,0.8)', fontSize: 13, lineHeight: 1.6, margin: 0 }}>
                      {result.explanation}
                    </p>
                  </div>
                )}

                {/* Transparent Math Breakdown */}
                {result.breakdown && (
                  <div style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    borderRadius: 'var(--radius-md)',
                    padding: '16px 20px',
                    marginTop: 14,
                    border: '1px dashed rgba(255, 255, 255, 0.15)',
                  }}>
                    <p style={{ color: 'var(--gold-300)', fontSize: 11, fontWeight: 700, marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
                      📊 Math Valuation Breakdown (Transparency Checklist)
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12.5, color: 'rgba(232, 245, 238, 0.85)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>📍 City Market Base Rate:</span>
                        <strong>{fmt(result.breakdown.baseRate)}/sqft/mo</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>📐 Size Area Base ({area} sqft):</span>
                        <strong>{fmt(result.breakdown.areaContribution)}/mo</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>🛏 BHK configuration multiplier ({bhk} BHK):</span>
                        <strong>× {result.breakdown.bhkFactor.toFixed(2)}</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>🪑 Furnishing multiplier ({furnishing}):</span>
                        <strong>× {result.breakdown.furnishingMultiplier.toFixed(2)}</strong>
                      </div>
                      {!isRent && (
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>💰 CAP Sale translation (12mo × 80 CAP):</span>
                          <strong>× 960 (Multiplier)</strong>
                        </div>
                      )}
                      <div style={{ height: 1, background: 'rgba(255, 255, 255, 0.15)', margin: '4px 0' }} />
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: 13.5, color: 'var(--text-on-dark)' }}>
                        <span>🔮 Exact Valuation Baseline:</span>
                        <span>{fmt(Math.round(result.breakdown.baseEstimate * result.breakdown.furnishingMultiplier * result.breakdown.saleMultiplier))}</span>
                      </div>
                    </div>
                  </div>
                )}

                <p style={{ color: 'rgba(232,245,238,0.4)', fontSize: 11, marginTop: 14, textAlign: 'center' }}>
                  Based on current Tamil Nadu market data. Actual prices may vary.
                </p>
              </div>
            )}

            {/* ── How it works ── */}
            <div style={{
              background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border)', padding: '20px 24px', marginTop: 20,
            }}>
              <h4 style={{ marginBottom: 12 }}>How the estimate works</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  ['📍 Location factor',   'Chennai has higher demand; smaller cities have lower base rates'],
                  ['🛏 BHK multiplier',    'More bedrooms increase the base estimate proportionally'],
                  ['📐 Area scaling',      'Larger properties command higher per-sqft premiums'],
                  ['🪑 Furnishing bonus',  'Fully furnished adds ~25%, semi furnished adds ~10%'],
                  ['💰 Sale multiplier',   'Sale price ≈ 80× annual rent based on Tamil Nadu cap rates'],
                  ['✨ AI explanation',    'Gemini adds a one-sentence market context if a key is configured'],
                ].map(([t, d]) => (
                  <div key={t} style={{ display: 'flex', gap: 10 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', minWidth: 180 }}>{t}</span>
                    <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{d}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px) }
          to   { opacity: 1; transform: translateY(0) }
        }
      `}</style>
    </MainLayout>
  )
}