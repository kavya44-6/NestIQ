import { useState, useEffect } from 'react'
import MainLayout from '../layouts/MainLayout'
import api from '../services/axiosConfig'
import { getAllMockProperties } from '../mock/mockStore'
import { properties as seedProperties } from '../data/properties'

const LOCALITIES_MOCK = {
  Chennai: [
    { name: 'Anna Nagar West', avgSale: 12500, avgRent: 35, growth: '+12.4%' },
    { name: 'Adyar Beachside', avgSale: 14200, avgRent: 42, growth: '+9.8%' },
    { name: 'OMR Sholinganallur', avgSale: 6800, avgRent: 22, growth: '+15.2%' },
    { name: 'ECR Sea Breeze', avgSale: 9500, avgRent: 32, growth: '+11.1%' }
  ],
  Coimbatore: [
    { name: 'Gandhipuram West', avgSale: 7500, avgRent: 20, growth: '+8.2%' },
    { name: 'Saravanampatti IT Corridor', avgSale: 4800, avgRent: 15, growth: '+13.5%' },
    { name: 'Avinashi Road', avgSale: 8200, avgRent: 24, growth: '+9.4%' },
    { name: 'RS Puram High Street', avgSale: 9800, avgRent: 28, growth: '+6.1%' }
  ],
  Madurai: [
    { name: 'KK Nagar', avgSale: 4900, avgRent: 12, growth: '+6.4%' },
    { name: 'Anna Nagar Madurai', avgSale: 5200, avgRent: 13, growth: '+7.1%' },
    { name: 'Simmakkal Central', avgSale: 7100, avgRent: 18, growth: '+3.8%' }
  ],
  Salem: [
    { name: 'Five Roads Junction', avgSale: 5200, avgRent: 14, growth: '+9.2%' },
    { name: 'Meyyanur Commercial', avgSale: 6100, avgRent: 16, growth: '+6.8%' },
    { name: 'Suramangalam', avgSale: 3900, avgRent: 10, growth: '+5.4%' }
  ],
  Tiruchirappalli: [
    { name: 'Cantonment', avgSale: 5500, avgRent: 15, growth: '+7.8%' },
    { name: 'Thillai Nagar', avgSale: 6200, avgRent: 18, growth: '+8.2%' },
    { name: 'Srirangam', avgSale: 4200, avgRent: 12, growth: '+6.1%' }
  ],
  Tiruppur: [
    { name: 'Avinashi Road', avgSale: 5100, avgRent: 13, growth: '+6.5%' },
    { name: 'Dharapuram Road', avgSale: 4300, avgRent: 11, growth: '+5.9%' }
  ],
  Vellore: [
    { name: 'Sathuvachari', avgSale: 4600, avgRent: 12, growth: '+6.2%' },
    { name: 'Gandhinagar', avgSale: 5000, avgRent: 14, growth: '+7.0%' }
  ]
}

export default function PriceTrends() {
  const [selectedCity, setSelectedCity] = useState('Chennai')
  const [chartType, setChartType] = useState('sale') // 'sale' | 'rent'
  const [marketData, setMarketData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchMarketAnalysis = async () => {
      setLoading(true)
      try {
        const res = await api.get(`/ai/market-analysis/${selectedCity}`)
        setMarketData(res.data)
      } catch (err) {
        console.error('Failed to fetch market analysis', err)
        
        // Calculate real averages from mock store and seed data
        const baseRate = selectedCity === 'Chennai' ? 22 : selectedCity === 'Coimbatore' ? 15 : selectedCity === 'Madurai' ? 12 : 10
        let saleAvg = baseRate * 1000 * 12 * 80 / 1000
        let rentAvg = baseRate

        const allProps = [...getAllMockProperties(), ...seedProperties].filter(p => p.city?.toLowerCase() === selectedCity.toLowerCase())
        const active = allProps.filter(p => p.status !== 'SOLD' && p.status !== 'RENTED')

        if (active.length > 0) {
          let saleSum = 0, saleCnt = 0
          let rentSum = 0, rentCnt = 0
          active.forEach(p => {
            const area = p.area && Number(p.area) > 0 ? Number(p.area) : 1000
            const price = Number(p.price || 0)
            if (p.listingType === 'SALE') {
              saleSum += (price / area)
              saleCnt++
            } else {
              rentSum += (price / area)
              rentCnt++
            }
          })
          if (saleCnt > 0) saleAvg = saleSum / saleCnt
          if (rentCnt > 0) rentAvg = rentSum / rentCnt
        }

        const growth = selectedCity === 'Chennai' ? '8.4%' : selectedCity === 'Coimbatore' ? '7.2%' : '5.8%'
        const liquidity = selectedCity === 'Chennai' ? 'High' : 'Moderate'
        const demand = selectedCity === 'Chennai' ? 'High' : 'Stable'

        setMarketData({
          city: selectedCity,
          avgSalePriceSqft: Math.round(saleAvg),
          avgRentPriceSqft: Math.round(rentAvg),
          appreciationRate: growth,
          liquidityScore: liquidity,
          demandQuotient: demand,
          diffSalePercent: 0,
          diffRentPercent: 0,
          buyerRecommendation: saleAvg > baseRate * 20 ? 'Asking rates are premium. Look for motivated sellers or properties with active RERA verification tags.' : 'Valuations are in line with local historical ranges. Focus on negotiation and look for high trust score profiles.',
          sellerRecommendation: 'Realize appreciation values by pricing within local sub-market bounds. Highlight lister verifications.',
          investmentOutlook: 'Stable rental assets perform best in this phase. Accumulate systematically.',
          aiMarketAnalysis: `The ${selectedCity} market exhibits a steady appreciation rate of ${growth} with consistent residential absorption across main corridors. Average sale pricing stands at ₹${Math.round(saleAvg)}/sqft and rent at ₹${Math.round(rentAvg)}/sqft/mo.`
        })
      } finally {
        setLoading(false)
      }
    }
    fetchMarketAnalysis()
  }, [selectedCity])

  const localities = LOCALITIES_MOCK[selectedCity] || LOCALITIES_MOCK.Chennai

  // Dynamic 5-year trend generator based on current average rates and appreciation
  const generateTrends = () => {
    if (!marketData) return []
    const appRateVal = parseFloat(marketData.appreciationRate.replace('%', '')) / 100
    const saleAvg = marketData.avgSalePriceSqft
    const rentAvg = marketData.avgRentPriceSqft

    return [
      { year: 2022, rent: Math.round(rentAvg / Math.pow(1 + appRateVal, 4)), sale: Math.round(saleAvg / Math.pow(1 + appRateVal, 4)) },
      { year: 2023, rent: Math.round(rentAvg / Math.pow(1 + appRateVal, 3)), sale: Math.round(saleAvg / Math.pow(1 + appRateVal, 3)) },
      { year: 2024, rent: Math.round(rentAvg / Math.pow(1 + appRateVal, 2)), sale: Math.round(saleAvg / Math.pow(1 + appRateVal, 2)) },
      { year: 2025, rent: Math.round(rentAvg / (1 + appRateVal)), sale: Math.round(saleAvg / (1 + appRateVal)) },
      { year: 2026, rent: Math.round(rentAvg), sale: Math.round(saleAvg) }
    ]
  }

  const trends = generateTrends()

  // Calculate coordinates for SVG line chart
  const padding = 45
  const chartWidth = 500
  const chartHeight = 220

  const getPoints = () => {
    if (trends.length === 0) return []
    const prices = trends.map(t => chartType === 'sale' ? t.sale : t.rent)
    const minVal = Math.min(...prices) * 0.85
    const maxVal = Math.max(...prices) * 1.15
    const valRange = maxVal - minVal

    return trends.map((t, idx) => {
      const x = padding + (idx * (chartWidth - padding * 2)) / (trends.length - 1)
      const val = chartType === 'sale' ? t.sale : t.rent
      const y = chartHeight - padding - ((val - minVal) * (chartHeight - padding * 2)) / (valRange || 1)
      return { x, y, ...t }
    })
  }

  const points = getPoints()
  const pathData = points.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')

  const yieldVal = marketData
    ? ((marketData.avgRentPriceSqft * 12) / marketData.avgSalePriceSqft * 100).toFixed(1) + '%'
    : '4.1%'

  const investmentScore = selectedCity === 'Chennai' ? '90/100' : selectedCity === 'Coimbatore' ? '82/100' : '72/100'

  return (
    <MainLayout>
      <div style={{ background: 'var(--green-50)', minHeight: '100vh', paddingBottom: 48 }}>
        <div className="container" style={{ paddingTop: 24 }}>
          
          {/* Header Section */}
          <div style={{ marginBottom: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
            <div>
              <h1 style={{ fontSize: 28, color: 'var(--text-primary)', fontWeight: 800, marginBottom: 6 }}>
                📈 Real Estate Price Trends & Market Analyzer
              </h1>
              <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
                Track live market average prices, historical growth indices, and smart investment outlooks for Tamil Nadu.
              </p>
            </div>

            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <span style={{ fontWeight: 600, fontSize: 14 }}>Select City:</span>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                style={{
                  padding: '8px 16px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1.5px solid var(--border)',
                  fontWeight: 600,
                  fontSize: 14,
                  cursor: 'pointer',
                  background: 'var(--cream-100)'
                }}
              >
                {Object.keys(LOCALITIES_MOCK).map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {loading || !marketData ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              <div className="skeleton" style={{ height: 120 }} />
              <div className="skeleton" style={{ height: 300 }} />
            </div>
          ) : (
            <>
              {/* Analytics Top Grid */}
              <div className="grid-4" style={{ marginBottom: 28 }}>
                {[
                  { icon: '💰', title: 'Avg Capital Value', value: `₹${marketData.avgSalePriceSqft.toLocaleString('en-IN')}/sqft`, desc: `Annual change: ${marketData.appreciationRate}` },
                  { icon: '🔑', title: 'Average Rent', value: `₹${marketData.avgRentPriceSqft}/sqft`, desc: 'Consistent demand scale' },
                  { icon: '📊', title: 'Rental Yield', value: yieldVal, desc: 'Gross return ratio' },
                  { icon: '⭐', title: 'Investment Score', value: investmentScore, desc: `Market Heat: ${marketData.demandQuotient}` }
                ].map(stat => (
                  <div key={stat.title} className="card card-body" style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ fontSize: 24, marginBottom: 8 }}>{stat.icon}</div>
                    <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.5px', color: 'var(--text-muted)', fontWeight: 600, marginBottom: 4 }}>
                      {stat.title}
                    </div>
                    <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--green-700)', marginBottom: 2 }}>{stat.value}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{stat.desc}</div>
                  </div>
                ))}
              </div>

              {/* Recommendation Panel */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginBottom: 28 }} className="trends-recommendations">
                <div style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 24, boxShadow: 'var(--shadow-sm)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                    <span style={{ fontSize: 22 }}>🛍️</span>
                    <h3 style={{ fontSize: 15, fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>Buyer Recommendation</h3>
                  </div>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--text-secondary)', margin: 0 }}>
                    {marketData.buyerRecommendation}
                  </p>
                </div>
                <div style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 24, boxShadow: 'var(--shadow-sm)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                    <span style={{ fontSize: 22 }}>🏷️</span>
                    <h3 style={{ fontSize: 15, fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>Seller Recommendation</h3>
                  </div>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--text-secondary)', margin: 0 }}>
                    {marketData.sellerRecommendation}
                  </p>
                </div>
                <div style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 24, boxShadow: 'var(--shadow-sm)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                    <span style={{ fontSize: 22 }}>💎</span>
                    <h3 style={{ fontSize: 15, fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>Investment Outlook</h3>
                  </div>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--text-secondary)', margin: 0 }}>
                    {marketData.investmentOutlook}
                  </p>
                </div>
              </div>

              {/* Main Analysis Chart and Localities Table */}
              <div style={{ display: 'grid', gridTemplateColumns: '1.8fr 1.2fr', gap: 24 }} className="trends-main-grid">
                
                {/* SVG Chart */}
                <div className="card card-body" style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)' }}>
                  <div className="flex-between" style={{ marginBottom: 16 }}>
                    <h3 style={{ fontSize: 16, fontWeight: 700 }}>📈 Growth Over Time (5-Year Trend)</h3>
                    <div style={{ display: 'flex', gap: 4, background: 'var(--cream-200)', padding: 3, borderRadius: 'var(--radius-sm)' }}>
                      <button
                        onClick={() => setChartType('sale')}
                        style={{
                          padding: '4px 12px', border: 'none', background: chartType === 'sale' ? 'var(--cream-200)' : 'transparent',
                          fontWeight: 700, fontSize: 12, borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                          boxShadow: chartType === 'sale' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                          color: 'var(--text-primary)'
                        }}
                      >
                        Capital Value
                      </button>
                      <button
                        onClick={() => setChartType('rent')}
                        style={{
                          padding: '4px 12px', border: 'none', background: chartType === 'rent' ? 'var(--cream-200)' : 'transparent',
                          fontWeight: 700, fontSize: 12, borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                          boxShadow: chartType === 'rent' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                          color: 'var(--text-primary)'
                        }}
                      >
                        Average Rent
                      </button>
                    </div>
                  </div>

                  <div style={{ overflowX: 'auto' }}>
                    <svg width="100%" height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} style={{ overflow: 'visible' }}>
                      {/* Horizontal lines */}
                      {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                        const y = padding + ratio * (chartHeight - padding * 2)
                        return (
                          <line key={idx} x1={padding} y1={y} x2={chartWidth - padding} y2={y} stroke="var(--border)" strokeDasharray="3,3" />
                        )
                      })}

                      {/* Line path */}
                      <path d={pathData} fill="none" stroke="var(--green-600)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />

                      {/* Area under the line */}
                      {points.length > 0 && (
                        <path
                          d={`${pathData} L ${points[points.length - 1].x} ${chartHeight - padding} L ${points[0].x} ${chartHeight - padding} Z`}
                          fill="url(#area-gradient)"
                          opacity="0.12"
                        />
                      )}

                      {/* Gradients */}
                      <defs>
                        <linearGradient id="area-gradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="var(--green-600)" />
                          <stop offset="100%" stopColor="var(--green-100)" />
                        </linearGradient>
                      </defs>

                      {/* Chart nodes */}
                      {points.map((p, idx) => (
                        <g key={idx}>
                          <circle cx={p.x} cy={p.y} r="5" fill="#fff" stroke="var(--green-700)" strokeWidth="2" />
                          <text x={p.x} y={p.y - 12} textAnchor="middle" fontSize="10" fontWeight="700" fill="var(--text-primary)">
                            {chartType === 'sale' ? `₹${p.sale}` : `₹${p.rent}`}
                          </text>
                          <text x={p.x} y={chartHeight - 12} textAnchor="middle" fontSize="10" fill="var(--text-muted)" fontWeight="600">
                            {p.year}
                          </text>
                        </g>
                      ))}
                    </svg>
                  </div>
                  
                  <div style={{ display: 'flex', justifyContent: 'center', gap: 20, marginTop: 12, fontSize: 12, color: 'var(--text-muted)' }}>
                    <span>🟢 Y-Axis: {chartType === 'sale' ? 'Sale Price (₹/sqft)' : 'Monthly Rent (₹/sqft)'}</span>
                    <span>📅 X-Axis: Calendar Year</span>
                  </div>
                </div>

                {/* Localities Table */}
                <div className="card card-body" style={{ background: 'var(--cream-100)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)' }}>
                  <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>🏡 Popular Localities in {selectedCity}</h3>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {localities.map(loc => (
                      <div key={loc.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'var(--cream-100)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text-primary)' }}>{loc.name}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                            ₹{loc.avgSale.toLocaleString('en-IN')}/sqft · Rent ₹{loc.avgRent}/sqft
                          </div>
                        </div>
                        <span style={{ fontSize: 12, background: 'var(--green-50)', color: 'var(--green-700)', padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>
                          {loc.growth}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* AI Location Analysis */}
              <div style={{ marginTop: 24, background: 'linear-gradient(135deg, var(--green-900), var(--green-800))', borderRadius: 'var(--radius-lg)', color: 'var(--text-on-dark)', padding: 28, boxShadow: 'var(--shadow-md)' }}>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 14 }}>
                  <span style={{ fontSize: 24 }}>🔮</span>
                  <h3 style={{ fontSize: 18, color: 'var(--green-300)', fontWeight: 800, margin: 0 }}>Smart Location Insights (AI-Orchestrated)</h3>
                </div>
                <p style={{ fontSize: 14.5, lineHeight: 1.6, color: 'rgba(255,255,255,0.85)', margin: 0, fontStyle: 'italic' }}>
                  "{marketData.aiMarketAnalysis}"
                </p>
                <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', marginTop: 20, borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 16, fontSize: 12, color: 'rgba(255,255,255,0.6)' }}>
                  <span>📈 Growth Potential: <strong>{marketData.appreciationRate} / yr</strong></span>
                  <span>💧 Liquidity Score: <strong>{marketData.liquidityScore}</strong></span>
                  <span>🔥 Demand Quotient: <strong>{marketData.demandQuotient}</strong></span>
                </div>
              </div>
            </>
          )}

        </div>
      </div>
      <style>{`
        @media (max-width: 991px) {
          .trends-recommendations { grid-template-columns: 1fr !important; gap: 16px !important; }
          .trends-main-grid { grid-template-columns: 1fr !important; gap: 24px !important; }
        }
      `}</style>
    </MainLayout>
  )
}
