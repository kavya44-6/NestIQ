// FILE: src/pages/owner/OwnerMessages.jsx  (NEW FILE)
import { useState, useEffect } from 'react'
import DashboardLayout from '../../layouts/DashboardLayout'
import Modal from '../../components/common/Modal'
import { getOwnerMessages, replyToAgentMessage } from '../../services/ownerService'
import { formatDate } from '../../utils/formatters'

function showToast(msg) {
  let container = document.getElementById('nestiq-toast-container')
  if (!container) {
    container = document.createElement('div')
    container.id = 'nestiq-toast-container'
    container.style.position = 'fixed'
    container.style.top = '20px'
    container.style.right = '20px'
    container.style.zIndex = '9999'
    container.style.display = 'flex'
    container.style.flexDirection = 'column'
    container.style.gap = '10px'
    document.body.appendChild(container)
  }
  
  const toast = document.createElement('div')
  toast.innerText = msg
  toast.style.background = 'var(--green-900)'
  toast.style.color = '#fff'
  toast.style.padding = '12px 24px'
  toast.style.borderRadius = 'var(--radius-md)'
  toast.style.boxShadow = 'var(--shadow-lg)'
  toast.style.fontWeight = '600'
  toast.style.borderLeft = '4px solid var(--green-300)'
  toast.style.fontSize = '13.5px'
  toast.style.transition = 'all 0.3s ease'
  toast.style.opacity = '0'
  toast.style.transform = 'translateY(-10px)'
  
  container.appendChild(toast)
  
  setTimeout(() => {
    toast.style.opacity = '1'
    toast.style.transform = 'translateY(0)'
  }, 10)
  
  setTimeout(() => {
    toast.style.opacity = '0'
    toast.style.transform = 'translateY(-10px)'
    setTimeout(() => {
      toast.remove()
      if (container.children.length === 0) {
        container.remove()
      }
    }, 300)
  }, 3000)
}

export default function OwnerMessages() {
  const [messages,   setMessages]   = useState([])
  const [loading,    setLoading]    = useState(true)
  const [selected,   setSelected]   = useState(null)
  const [reply,      setReply]      = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [success,    setSuccess]    = useState('')

  const fetchMessages = (isSilent = false) => {
    if (!isSilent) setLoading(true)
    getOwnerMessages()
      .then(r => {
        const newData = r.data || []
        setMessages(prev => {
          if (JSON.stringify(prev) === JSON.stringify(newData)) {
            return prev
          }
          if (isSilent && prev.length > 0) {
            newData.forEach(newItem => {
              const oldItem = prev.find(o => o.id === newItem.id)
              if (oldItem && oldItem.status !== newItem.status) {
                showToast("Owner received your message")
              }
            })
          }
          return newData
        })
      })
      .catch(() => {})
      .finally(() => {
        if (!isSilent) setLoading(false)
      })
  }

  useEffect(() => {
    fetchMessages(false)
    const interval = setInterval(() => {
      fetchMessages(true)
    }, 15000)
    return () => clearInterval(interval)
  }, [])

  const handleReply = async () => {
    if (!reply.trim() || !selected) return
    setSubmitting(true)
    try {
      await replyToAgentMessage(selected.id, reply)
      setSuccess('Reply sent to agent!')
      setSelected(null)
      setReply('')
      fetchMessages()
    } catch {
      setSuccess('error')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="dashboard-header">
        <h2>Agent Messages</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
          Messages from agents managing your properties — reply to give instructions or approvals
        </p>
      </div>

      {success && success !== 'error' && (
        <div className="alert alert-success" style={{ marginBottom: 16 }}>✅ {success}</div>
      )}
      {success === 'error' && (
        <div className="alert alert-error" style={{ marginBottom: 16 }}>Something went wrong. Please try again.</div>
      )}

      <div style={{ background: 'rgba(217, 119, 6, 0.1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '14px 18px', marginBottom: 20, fontSize: 14, color: 'var(--text-secondary)' }}>
        💡 When an agent contacts you about a customer inquiry or visit request, it shows up here. Reply directly to give your go-ahead or special instructions.
      </div>

      {loading ? <div className="loading-page"><div className="spinner" /></div> :
       messages.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📨</div>
          <p>No messages from agents yet. Messages appear here when an agent contacts you about your property.</p>
        </div>
       ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{ background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)', border: `1px solid ${msg.status === 'PENDING' ? '#fca5a5' : 'var(--border)'}`, padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{msg.propertyTitle || `Property #${msg.propertyId}`}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                    From: <strong>{msg.agentName || 'Agent'}</strong> · {formatDate(msg.createdAt)}
                  </div>
                </div>
                <span className={`badge ${msg.status === 'REPLIED' ? 'badge-green' : 'badge-gold'}`}>{msg.status}</span>
              </div>

              {/* Agent's message */}
              <div style={{ background: 'var(--green-50)', borderRadius: 'var(--radius-md)', padding: '12px 14px', marginBottom: 12 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--green-700)', marginBottom: 4 }}>📤 Agent's Message</div>
                <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.agentMessage}</p>
              </div>

              {/* Your reply */}
              {msg.ownerReply ? (
                <div style={{ background: 'rgba(217, 119, 6, 0.1)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '12px 14px' }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>✅ Your Reply · {formatDate(msg.repliedAt)}</div>
                  <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{msg.ownerReply}</p>
                </div>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <p style={{ fontSize: 12, color: '#b91c1c', margin: 0 }}>⏳ Awaiting your reply</p>
                  <button className="btn btn-primary btn-sm" onClick={() => { setSelected(msg); setReply('') }}>
                    Reply Now
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
       )}

      {/* Reply Modal */}
      <Modal isOpen={!!selected} onClose={() => setSelected(null)} title="Reply to Agent">
        {selected && (
          <>
            <div style={{ background: 'var(--green-50)', borderRadius: 'var(--radius-md)', padding: '12px 14px', marginBottom: 16, fontSize: 14 }}>
              <strong>{selected.agentName}:</strong> {selected.agentMessage}
            </div>
            <div className="form-group">
              <label>Your Reply</label>
              <textarea value={reply} onChange={e => setReply(e.target.value)} rows={4}
                placeholder="e.g. Yes, the property is available. Please confirm the visit for Saturday 11 AM." />
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="btn btn-outline btn-sm" onClick={() => setSelected(null)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={handleReply} disabled={submitting || !reply.trim()}>
                {submitting ? 'Sending...' : 'Send Reply'}
              </button>
            </div>
          </>
        )}
      </Modal>
    </DashboardLayout>
  )
}