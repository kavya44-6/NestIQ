import { useState, useEffect } from 'react'
import DashboardLayout from '../../layouts/DashboardLayout'
import api from '../../services/axiosConfig'
import { formatPrice } from '../../utils/formatters'

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProperties: 0,
    totalInquiries: 0,
    totalVisits: 0,
    pendingKyc: 0,
    lowTrustProperties: 0
  })
  const [users, setUsers] = useState([])
  const [properties, setProperties] = useState([])
  const [loading, setLoading] = useState(true)
  const [toastMsg, setToastMsg] = useState('')
  const [kycLoadingId, setKycLoadingId] = useState(null)
  const [recalcLoadingId, setRecalcLoadingId] = useState(null)

  const showToast = (msg) => {
    setToastMsg(msg)
    setTimeout(() => setToastMsg(''), 3000)
  }

  const fetchData = async () => {
    try {
      const statsRes = await api.get('/admin/stats')
      const usersRes = await api.get('/admin/users')
      const propsRes = await api.get('/admin/properties')
      setStats(statsRes.data)
      setUsers(usersRes.data)
      setProperties(propsRes.data)
    } catch (err) {
      showToast('❌ Failed to fetch admin data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleVerifyKyc = async (userId) => {
    setKycLoadingId(userId)
    try {
      await api.put(`/admin/kyc/${userId}/verify`)
      showToast('✅ KYC verified successfully')
      setUsers(prev => prev.filter(u => u.id !== userId))
      setStats(prev => ({ ...prev, pendingKyc: Math.max(0, prev.pendingKyc - 1) }))
    } catch (err) {
      showToast('❌ Failed to verify KYC')
    } finally {
      setKycLoadingId(null)
    }
  }

  const handleRejectKyc = async (userId) => {
    setKycLoadingId(userId)
    try {
      await api.put(`/admin/kyc/${userId}/reject`)
      showToast('⚠️ KYC request rejected')
      setUsers(prev => prev.filter(u => u.id !== userId))
      setStats(prev => ({ ...prev, pendingKyc: Math.max(0, prev.pendingKyc - 1) }))
    } catch (err) {
      showToast('❌ Failed to reject KYC')
    } finally {
      setKycLoadingId(null)
    }
  }

  const handleRemoveProperty = async (propertyId) => {
    try {
      await api.delete(`/admin/property/${propertyId}`)
      showToast('🗑️ Property deleted successfully')
      setProperties(prev => prev.filter(p => p.id !== propertyId))
      setStats(prev => ({ 
        ...prev, 
        totalProperties: Math.max(0, prev.totalProperties - 1),
        lowTrustProperties: Math.max(0, prev.lowTrustProperties - 1)
      }))
    } catch (err) {
      showToast('❌ Failed to delete property')
    }
  }

  const handleApproveProperty = async (propertyId) => {
    try {
      await api.put(`/admin/property/${propertyId}/approve`)
      showToast('✅ Property approved')
      setProperties(prev => prev.map(p => p.id === propertyId ? { ...p, approved: true, status: 'AVAILABLE' } : p))
    } catch (err) {
      showToast('❌ Failed to approve property')
    }
  }

  const handleRejectProperty = async (propertyId) => {
    try {
      await api.put(`/admin/property/${propertyId}/reject`)
      showToast('❌ Property rejected')
      setProperties(prev => prev.map(p => p.id === propertyId ? { ...p, approved: false, status: 'REJECTED' } : p))
    } catch (err) {
      showToast('❌ Failed to reject property')
    }
  }

  const handleRecalculateTrust = async (propertyId) => {
    setRecalcLoadingId(propertyId)
    try {
      await api.put(`/admin/property/${propertyId}/recalculate-trust`)
      showToast('🔄 Trust score recalculated successfully')
      await fetchData()
    } catch (err) {
      showToast('❌ Failed to recalculate trust score')
    } finally {
      setRecalcLoadingId(null)
    }
  }

  const pendingKycUsers = users.filter(u => u.kycStatus === 'SUBMITTED')
  const lowTrustProps = properties.filter(p => p.trustScore !== null && p.trustScore < 40)

  if (loading) {
    return (
      <DashboardLayout>
        <div className="skeleton" style={{ height: 400 }} />
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      {/* Toast Alert */}
      {toastMsg && (
        <div style={{
          position: 'fixed', top: 20, right: 20, background: 'var(--green-900)', color: '#fff',
          padding: '12px 24px', borderRadius: 'var(--radius-md)', zIndex: 1000,
          boxShadow: 'var(--shadow-lg)', fontWeight: 600, borderLeft: '4px solid var(--green-300)'
        }}>
          {toastMsg}
        </div>
      )}

      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 4 }}>
          🛡️ Platform Administration Panel
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 13.5 }}>
          Monitor user growth, listing quality standards, fraud reports, and platform KPIs.
        </p>
      </div>

      {/* SECTION 1 — Stats Row */}
      <div className="stats-grid" style={{ marginBottom: 28 }}>
        <div className="stat-card" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: 26 }}>👥</span>
            <span style={{ fontSize: 11, background: 'var(--green-50)', color: 'var(--green-700)', padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>
              Active Users
            </span>
          </div>
          <div style={{ fontSize: 12, textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, marginTop: 12, marginBottom: 4 }}>
            Total Users
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
            {stats.totalUsers}
          </div>
        </div>

        <div className="stat-card" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: 26 }}>🏠</span>
            <span style={{ fontSize: 11, background: 'var(--green-50)', color: 'var(--green-700)', padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>
              Listings
            </span>
          </div>
          <div style={{ fontSize: 12, textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, marginTop: 12, marginBottom: 4 }}>
            Total Properties
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
            {stats.totalProperties}
          </div>
        </div>

        <div className="stat-card" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: 26 }}>📄</span>
            <span style={{ fontSize: 11, background: 'var(--gold-50)', color: 'var(--gold-700)', padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>
              Action Required
            </span>
          </div>
          <div style={{ fontSize: 12, textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, marginTop: 12, marginBottom: 4 }}>
            Pending KYC
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
            {stats.pendingKyc}
          </div>
        </div>

        <div className="stat-card" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: 26 }}>⚠️</span>
            <span style={{ fontSize: 11, background: 'var(--red-50)', color: 'var(--red-700)', padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>
              Flagged
            </span>
          </div>
          <div style={{ fontSize: 12, textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, marginTop: 12, marginBottom: 4 }}>
            Low Trust Properties
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
            {stats.lowTrustProperties}
          </div>
        </div>
      </div>

      {/* SECTION 2 — Pending KYC table */}
      <div className="card card-body" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', marginBottom: 28 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>📄 Pending KYC Document Reviews</h3>
        {pendingKycUsers.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: 13.5, margin: 0 }}>No pending KYC document reviews.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Document Type</th>
                <th>Document Number</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pendingKycUsers.map(u => (
                <tr key={u.id}>
                  <td style={{ fontWeight: 600 }}>{u.name}</td>
                  <td>{u.email}</td>
                  <td><span className="tag" style={{ textTransform: 'capitalize' }}>{u.role.toLowerCase()}</span></td>
                  <td>{u.kycDocumentType || 'N/A'}</td>
                  <td style={{ fontFamily: 'monospace' }}>{u.kycDocumentNumber || 'N/A'}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button 
                        className="btn btn-primary btn-sm" 
                        style={{ padding: '4px 10px', fontSize: 11 }} 
                        onClick={() => handleVerifyKyc(u.id)}
                        disabled={kycLoadingId !== null}
                      >
                        {kycLoadingId === u.id ? '...' : 'Verify'}
                      </button>
                      <button 
                        className="btn btn-danger btn-sm" 
                        style={{ padding: '4px 10px', fontSize: 11 }} 
                        onClick={() => handleRejectKyc(u.id)}
                        disabled={kycLoadingId !== null}
                      >
                        {kycLoadingId === u.id ? '...' : 'Reject'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* SECTION 3 — Low Trust Properties table */}
      <div className="card card-body" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', marginBottom: 28 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>⚠️ Flagged Low Trust Listings</h3>
        {lowTrustProps.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: 13.5, margin: 0 }}>No low trust listings found.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>City</th>
                <th>Trust Score</th>
                <th>Owner/Lister</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {lowTrustProps.map(p => (
                <tr key={p.id}>
                  <td style={{ fontWeight: 600 }}>{p.title}</td>
                  <td>{p.city}</td>
                  <td>
                    <span className="badge badge-red" style={{ fontWeight: 700 }}>
                      {p.trustScore}%
                    </span>
                  </td>
                  <td>{p.ownerName || p.agentName || 'Platform Seeder'}</td>
                  <td><span className={`badge badge-${p.status === 'AVAILABLE' ? 'green' : 'red'}`}>{p.status}</span></td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button 
                        className="btn btn-outline btn-sm" 
                        style={{ padding: '4px 10px', fontSize: 11 }} 
                        onClick={() => handleRecalculateTrust(p.id)}
                        disabled={recalcLoadingId === p.id}
                      >
                        {recalcLoadingId === p.id ? 'Recalculating...' : 'Recalculate'}
                      </button>
                      <button className="btn btn-danger btn-sm" style={{ padding: '4px 10px', fontSize: 11 }} onClick={() => handleRemoveProperty(p.id)}>
                        Remove Listing
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* SECTION 4 — All Properties table */}
      <div className="card card-body" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>🏡 All Listings & Auditing</h3>
        <table className="data-table">
          <thead>
            <tr>
              <th>Title</th>
              <th>City</th>
              <th>BHK</th>
              <th>Price</th>
              <th>Status</th>
              <th>Trust Score</th>
              <th>Agent/Lister</th>
              <th>Verification</th>
            </tr>
          </thead>
          <tbody>
            {properties.map(p => (
              <tr key={p.id}>
                <td style={{ fontWeight: 600 }}>{p.title}</td>
                <td>{p.city}</td>
                <td>{p.bhk} BHK</td>
                <td style={{ fontWeight: 700, color: 'var(--green-700)' }}>{formatPrice(p.price)}</td>
                <td>
                  <span className={`badge badge-${p.approved ? 'green' : 'red'}`}>
                    {p.approved ? 'APPROVED' : 'REJECTED'}
                  </span>
                </td>
                <td>
                  <span className={`badge badge-${p.trustScore >= 80 ? 'green' : p.trustScore >= 60 ? 'gold' : 'red'}`}>
                    {p.trustScore || 0}%
                  </span>
                </td>
                <td>{p.agentName || p.ownerName || 'Lister'}</td>
                <td>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button 
                      className="btn btn-primary btn-sm" 
                      style={{ padding: '4px 10px', fontSize: 11 }} 
                      onClick={() => handleApproveProperty(p.id)}
                      disabled={p.approved}
                    >
                      Approve
                    </button>
                    <button 
                      className="btn btn-danger btn-sm" 
                      style={{ padding: '4px 10px', fontSize: 11 }} 
                      onClick={() => handleRejectProperty(p.id)}
                      disabled={!p.approved}
                    >
                      Reject
                    </button>
                    <button 
                      className="btn btn-outline btn-sm" 
                      style={{ padding: '4px 10px', fontSize: 11 }} 
                      onClick={() => handleRecalculateTrust(p.id)}
                      disabled={recalcLoadingId === p.id}
                    >
                      {recalcLoadingId === p.id ? 'Recalculating...' : 'Recalculate'}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  )
}
