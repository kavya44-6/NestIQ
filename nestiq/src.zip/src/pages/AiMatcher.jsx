import { useState } from 'react'
import { Link } from 'react-router-dom'
import MainLayout from '../layouts/MainLayout'
import { getAiRecommendations } from '../services/aiService'
import { CITIES } from '../config/constants'
import { formatPrice } from '../utils/formatters'

const LIFESTYLE_SUGGESTIONS = [
  'near schools', 'close to IT park', 'quiet neighbourhood',
  'pet friendly', 'near hospital', 'good public transport',
]

const INCOME_PRESETS = [
  { label: '₹20k', value: '20000' },
  { label: '₹40k', value: '40000' },
  { label: '₹60k', value: '60000' },
  { label: '₹80k', value: '80000' },
  { label: '₹1.2L+', value: '120000' },
]

export default function AiMatcher() {
  const [form, setForm] = useState({
    income:         '',
    familySize:     '',
    preferredCity:  '',
    workplaceArea:  '',
    lifestyleNeeds: '',
  })
  const [results,  setResults]  = useState(null)
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState('')

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const handleSubmit = async () => {
    setError('')
    if (!form.income)     { setError('Please enter your monthly income.'); return }
    if (!form.familySize) { setError('Please enter your family size.'); return }

    setLoading(true)
    setResults(null)
    try {
      const data = await getAiRecommendations({
        income:        Number(form.income),
        familySize:    Number(form.familySize),
        preferredCity: form.preferredCity  || null,
        workplaceArea: form.workplaceArea  || null,
        lifestyleNeeds:form.lifestyleNeeds || null,
      })
      setResults(Array.isArray(data) ? data : [])
    } catch {
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <div style={{ paddingTop: 'var(--navbar-height)', background: 'var(--green-50)', minHeight: '100vh' }}>

        {/* Banner Section */}
        <div style={{ background: 'var(--green-900)', padding: '40px 0 36px', borderBottom: '4px solid var(--gold-400)' }}>
          <div className="container">
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 4 }}>
              <span style={{ fontSize: 40 }}>🤖</span>
              <div>
                <h1 style={{ color: 'var(--text-on-dark)', fontSize: 30, fontWeight: 800, margin: 0 }}>AI Property Matcher</h1>
                <p style={{ color: 'rgba(232,245,238,0.75)', fontSize: 14, margin: '4px 0 0 0' }}>
                  Analyze NestIQ listings to find your ideal home using customized lifestyle matching constraints.
                </p>
              </div>
            </div>
            <div style={{ marginTop: 16, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {['100% Free Analyser', 'Direct Agent Connect', 'Tamil Nadu Focused', 'No Sign-up Needed'].map(tag => (
                <span key={tag} style={{
                  background: 'rgba(255,255,255,0.1)', color: 'var(--gold-400)',
                  borderRadius: 'var(--radius-sm)', padding: '4px 12px', fontSize: 12, fontWeight: 700,
                }}>{tag}</span>
              ))}
            </div>
          </div>
        </div>

        <div className="container" style={{ padding: '36px 24px' }}>
          <div
            style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: 32, alignItems: 'start' }}
            className="matcher-grid"
          >
            {/* Preferences Form */}
            <div style={{
              background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border)', padding: 28,
              boxShadow: 'var(--shadow-md)', position: 'sticky', top: 90,
            }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, margin: '0 0 4px 0' }}>Your Preferences</h2>
              <p style={{ color: 'var(--text-muted)', fontSize: 13, margin: '0 0 24px 0' }}>
                Fill details to calculate matches instantly.
              </p>

              {error && <div className="alert alert-error" style={{ marginBottom: 16 }}>{error}</div>}

              {/* Monthly Income input with Presets */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, display: 'block' }}>Monthly Income (₹) *</label>
                <input
                  type="number"
                  placeholder="e.g. 45000"
                  value={form.income}
                  onChange={e => set('income', e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', fontSize: 14 }}
                />
                
                {/* Presets Row */}
                <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                  {INCOME_PRESETS.map(preset => (
                    <button
                      key={preset.value}
                      type="button"
                      onClick={() => set('income', preset.value)}
                      style={{
                        padding: '4px 10px', fontSize: 11, borderRadius: 'var(--radius-sm)',
                        border: '1px solid var(--border)', background: 'var(--cream-100)',
                        color: 'var(--text-secondary)', cursor: 'pointer', fontWeight: 600
                      }}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {form.income && (
                  <p style={{ fontSize: 12, color: 'var(--green-700)', marginTop: 8, fontWeight: 500 }}>
                    💡 Estimated budget limit (Rent/EMI): <strong>₹{Math.round(Number(form.income) * 0.4).toLocaleString('en-IN')}/mo</strong>
                  </p>
                )}
              </div>

              {/* Family size selection */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, display: 'block' }}>Family Size *</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  {[1, 2, 3, 4, '5+'].map(n => {
                    const val  = n === '5+' ? 5 : n
                    const active = form.familySize == val || (n === '5+' && form.familySize >= 5)
                    return (
                      <button
                        key={n}
                        type="button"
                        onClick={() => set('familySize', val)}
                        style={{
                          flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)',
                          border: `1.5px solid ${active ? 'var(--green-500)' : 'var(--border)'}`,
                          background: active ? 'var(--green-600)' : 'transparent',
                          color: active ? 'var(--text-on-dark)' : 'var(--text-secondary)',
                          cursor: 'pointer', fontSize: 13, fontWeight: 700, transition: 'all 0.15s'
                        }}
                      >{n}</button>
                    )
                  })}
                </div>
              </div>

              {/* City Selection */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, display: 'block' }}>Preferred City</label>
                <select 
                  value={form.preferredCity} 
                  onChange={e => set('preferredCity', e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', fontSize: 14 }}
                >
                  <option value="">Any city in Tamil Nadu</option>
                  {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              {/* Workplace Area */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, display: 'block' }}>Workplace / Near Area</label>
                <input
                  type="text"
                  placeholder="e.g. OMR, Saravanampatti, Central"
                  value={form.workplaceArea}
                  onChange={e => set('workplaceArea', e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', fontSize: 14 }}
                />
              </div>

              {/* Lifestyle text area */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, display: 'block' }}>Lifestyle Needs</label>
                <textarea
                  placeholder="e.g. near schools, quiet area, pet friendly"
                  value={form.lifestyleNeeds}
                  onChange={e => set('lifestyleNeeds', e.target.value)}
                  rows={2}
                  style={{ resize: 'none', width: '100%', padding: '10px 12px', fontSize: 14 }}
                />
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
                  {LIFESTYLE_SUGGESTIONS.map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => set('lifestyleNeeds', form.lifestyleNeeds ? form.lifestyleNeeds + ', ' + s : s)}
                      style={{
                        background: 'var(--green-50)', border: '1px solid var(--green-200)',
                        color: 'var(--green-700)', borderRadius: 999,
                        padding: '4px 10px', fontSize: 11, cursor: 'pointer', fontWeight: 600
                      }}
                    >
                      + {s}
                    </button>
                  ))}
                </div>
              </div>

              <button
                className="btn btn-primary btn-full btn-lg"
                onClick={handleSubmit}
                disabled={loading}
                style={{ marginTop: 8, justifyContent: 'center' }}
              >
                {loading ? '🔍 Finding Matches…' : '✨ Match My Profile'}
              </button>
            </div>

            {/* Results Column */}
            <div>
              {results === null && !loading && (
                <div style={{
                  background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)',
                  border: '2px dashed var(--border)', padding: '56px 40px', textAlign: 'center',
                }}>
                  <div style={{ fontSize: 56, marginBottom: 16 }}>🤖</div>
                  <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8, color: 'var(--text-primary)' }}>Find properties matched to your lifestyle</h3>
                  <p style={{ color: 'var(--text-muted)', fontSize: 14, maxWidth: 440, margin: '0 auto' }}>
                    Enter your income and family constraints on the left. The algorithm will rank listings and write a customized explanation for you.
                  </p>
                </div>
              )}

              {loading && (
                <div style={{ textAlign: 'center', padding: '80px 20px', background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
                  <div className="spinner" style={{ margin: '0 auto 16px' }} />
                  <p style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Analyzing and ranking active listings...</p>
                  <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>Gemini is matching pricing distributions to your household index</p>
                </div>
              )}

              {results !== null && results.length === 0 && !loading && (
                <div className="empty-state" style={{ background: 'var(--cream-100)', padding: 48, borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
                  <div className="empty-icon">🔍</div>
                  <p style={{ fontWeight: 800 }}>No perfect matches found.</p>
                  <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '-8px 0 16px 0' }}>
                    Try lowering your budget, changing city fields, or expanding lifestyle words.
                  </p>
                </div>
              )}

              {results !== null && results.length > 0 && !loading && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                    <span style={{ fontSize: 14, color: 'var(--text-secondary)', fontWeight: 600 }}>
                      Matched <strong>{results.length}</strong> listings to your profile
                    </span>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
                    {results.map((item, i) => (
                      <MatchCard key={item.property?.id ?? i} item={item} rank={i + 1} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 991px) {
          .matcher-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </MainLayout>
  )
}

function MatchCard({ item, rank }) {
  const { property, reasoning, matchScore } = item
  if (!property) return null

  const FALLBACK = 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80'
  const [imgErr, setImgErr] = useState(false)
  const rankColors = ['#16a34a', '#d97706', '#6b7280']
  const rankColor  = rankColors[rank - 1] || '#6b7280'

  return (
    <div style={{
      background: 'var(--cream-100)', borderRadius: 'var(--radius-lg)',
      border: `2px solid ${rank === 1 ? 'var(--green-400)' : 'var(--border)'}`,
      overflow: 'hidden', boxShadow: 'var(--shadow-sm)',
    }}>
      <div
        style={{ display: 'grid', gridTemplateColumns: '240px 1fr', minHeight: 180 }}
        className="match-inner"
      >
        {/* Image / Rank badge */}
        <div style={{ position: 'relative', overflow: 'hidden' }}>
          <img
            src={imgErr ? FALLBACK : (property.imageUrl || FALLBACK)}
            alt={property.title}
            onError={() => setImgErr(true)}
            style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          />
          <div style={{
            position: 'absolute', top: 12, left: 12,
            background: rankColor, color: 'var(--text-on-dark)',
            borderRadius: 999, width: 32, height: 32,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 800, fontSize: 14, boxShadow: 'var(--shadow-md)'
          }}>
            #{rank}
          </div>
        </div>

        {/* Content Details */}
        <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 800, margin: '0 0 2px 0', color: 'var(--text-primary)' }}>{property.title}</h3>
              <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0 }}>
                📍 {property.city}{property.address ? ` · ${property.address}` : ''}
              </p>
            </div>
            {matchScore != null && (
              <span style={{
                background: 'var(--green-50)', color: 'var(--green-700)',
                border: '1px solid var(--green-200)',
                borderRadius: '999px', padding: '4px 12px', fontSize: 11, fontWeight: 700,
                whiteSpace: 'nowrap',
              }}>
                ✨ {matchScore}% MATCH
              </span>
            )}
          </div>

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {property.bedrooms  && <Chip>🛏 {property.bedrooms} BHK</Chip>}
            {property.area      && <Chip>📐 {property.area} sqft</Chip>}
            {property.propertyType && <Chip>🏗 {property.propertyType}</Chip>}
          </div>

          <p style={{ fontSize: 20, fontWeight: 800, color: 'var(--green-600)', margin: 0 }}>
            {property.price ? formatPrice(property.price) : '—'}
          </p>

          {reasoning && (
            <div style={{
              background: 'var(--green-50)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)', padding: '12px 16px',
              fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6,
            }}>
              <span style={{ color: 'var(--text-primary)', fontWeight: 700, marginRight: 6 }}>🤖 AI Verdict:</span>
              {reasoning}
            </div>
          )}

          {/* Detailed Score Breakdown */}
          <div style={{
            marginTop: 8, padding: '14px 18px', background: '#f8fafc',
            border: '1px solid var(--border)', borderRadius: 'var(--radius-md)',
            display: 'flex', flexDirection: 'column', gap: 10
          }}>
            <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--text-primary)', borderBottom: '1px solid var(--border)', paddingBottom: 6, display: 'flex', justifyContent: 'space-between' }}>
              <span>📊 Matching Breakdown</span>
              <span style={{ color: 'var(--green-700)' }}>Max 100 pts</span>
            </div>
            
            {[
              { label: '💰 Rent/EMI Budget Fit', val: item.budgetFit || 12.5, max: 25 },
              { label: '👨‍👩‍👧 Family BHK Alignment', val: item.familySizeFit || 10, max: 20 },
              { label: '📍 City Preference Match', val: item.cityMatch || 7.5, max: 15 },
              { label: '🛡️ Trust Score Contribution', val: item.trustScoreContrib || 10, max: 20 },
              { label: '🌲 Lifestyle Compatibility', val: item.lifestyleMatch || 10, max: 20 }
            ].map(row => {
              const percentage = (row.val / row.max) * 100
              return (
                <div key={row.label} style={{ display: 'grid', gridTemplateColumns: '170px 1fr 50px', alignItems: 'center', gap: 12, fontSize: 12 }}>
                  <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>{row.label}</span>
                  <div style={{ height: 6, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{ width: `${percentage}%`, height: '100%', background: 'var(--green-600)', borderRadius: 3 }} />
                  </div>
                  <span style={{ textAlign: 'right', fontWeight: 700, color: 'var(--text-primary)' }}>{row.val}/{row.max}</span>
                </div>
              )
            })}
          </div>

          <Link
            to={`/properties/${property.id}`}
            className="btn btn-primary btn-sm"
            style={{ alignSelf: 'flex-start', marginTop: 4, textDecoration: 'none', justifyContent: 'center' }}
          >
            View Details →
          </Link>
        </div>
      </div>

      <style>{`
        @media (max-width: 600px) {
          .match-inner { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  )
}

function Chip({ children }) {
  return (
    <span style={{
      background: 'var(--cream-100)', borderRadius: 'var(--radius-sm)',
      padding: '4px 10px', fontSize: 12, color: 'var(--text-secondary)', fontWeight: 600,
    }}>
      {children}
    </span>
  )
}