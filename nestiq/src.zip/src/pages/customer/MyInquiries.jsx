import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import DashboardLayout from '../../layouts/DashboardLayout'
import { getMyInquiries } from '../../services/inquiryService'
import { formatDate } from '../../utils/formatters'

function showToast(msg) {
  let container = document.getElementById('nestiq-toast-container')
  if (!container) {
    container = document.createElement('div')
    container.id = 'nestiq-toast-container'
    container.style.position = 'fixed'
    container.style.top = '20px'
    container.style.right = '20px'
    container.style.zIndex = '9999'
    container.style.display = 'flex'
    container.style.flexDirection = 'column'
    container.style.gap = '10px'
    document.body.appendChild(container)
  }
  
  const toast = document.createElement('div')
  toast.innerText = msg
  toast.style.background = 'var(--green-900)'
  toast.style.color = '#fff'
  toast.style.padding = '12px 24px'
  toast.style.borderRadius = 'var(--radius-md)'
  toast.style.boxShadow = 'var(--shadow-lg)'
  toast.style.fontWeight = '600'
  toast.style.borderLeft = '4px solid var(--green-300)'
  toast.style.fontSize = '13.5px'
  toast.style.transition = 'all 0.3s ease'
  toast.style.opacity = '0'
  toast.style.transform = 'translateY(-10px)'
  
  container.appendChild(toast)
  
  setTimeout(() => {
    toast.style.opacity = '1'
    toast.style.transform = 'translateY(0)'
  }, 10)
  
  setTimeout(() => {
    toast.style.opacity = '0'
    toast.style.transform = 'translateY(-10px)'
    setTimeout(() => {
      toast.remove()
      if (container.children.length === 0) {
        container.remove()
      }
    }, 300)
  }, 3000)
}

export default function MyInquiries() {
  const [inquiries, setInquiries] = useState([])
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    const fetchData = (isSilent = false) => {
      if (!isSilent) setLoading(true)
      getMyInquiries()
        .then(r => {
          const newData = r.data || []
          setInquiries(prev => {
            if (JSON.stringify(prev) === JSON.stringify(newData)) {
              return prev
            }
            if (isSilent && prev.length > 0) {
              newData.forEach(newItem => {
                const oldItem = prev.find(o => o.id === newItem.id)
                if (oldItem && oldItem.status === 'NEW' && newItem.status === 'RESPONDED') {
                  showToast(`Agent responded to your inquiry about ${newItem.propertyTitle || 'property'}`)
                }
              })
            }
            return newData
          })
        })
        .catch(() => {})
        .finally(() => {
          if (!isSilent) setLoading(false)
        })
    }

    fetchData(false)
    const interval = setInterval(() => {
      fetchData(true)
    }, 15000)
    return () => clearInterval(interval)
  }, [])

  return (
    <DashboardLayout>
      <div className="dashboard-header">
        <h2>My Inquiries</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Track all inquiries you've sent to agents</p>
      </div>

      {loading ? <div className="loading-page"><div className="spinner" /></div> :
       inquiries.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">💬</div>
          <p>You haven't sent any inquiries yet.</p>
          <Link to="/properties" className="btn btn-primary">Browse Properties</Link>
        </div>
       ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Property</th><th>Message</th><th>Date</th><th>Status</th><th>Response</th></tr></thead>
            <tbody>
              {inquiries.map(inq => (
                <tr key={inq.id}>
                  <td>
                    <Link to={`/properties/${inq.propertyId}`} style={{ color: 'var(--green-600)', fontWeight: 600 }}>
                      {inq.propertyTitle || `Property #${inq.propertyId}`}
                    </Link>
                  </td>
                  <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{inq.message}</td>
                  <td>{formatDate(inq.createdAt)}</td>
                  <td>
                    <span className={`badge ${inq.status === 'RESPONDED' ? 'badge-green' : inq.status === 'CLOSED' ? 'badge-grey' : 'badge-gold'}`}>
                      {inq.status}
                    </span>
                  </td>
                  <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                    {inq.agentResponse || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
       )}
    </DashboardLayout>
  )
}