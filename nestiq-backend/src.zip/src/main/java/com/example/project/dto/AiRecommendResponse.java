package com.example.project.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiRecommendResponse {
    private PropertyDTO property;
    private double      matchScore;
    private String      reasoning;
    
    // Breakdown metrics (max 100 total: 25 budget, 20 family, 15 city, 20 trust, 20 lifestyle)
    private double      budgetFit;
    private double      familySizeFit;
    private double      cityMatch;
    private double      trustScoreContrib;
    private double      lifestyleMatch;
}
