package com.example.project.config;

import com.example.project.entity.Property;
import com.example.project.entity.Role;
import com.example.project.entity.User;
import com.example.project.repository.PropertyRepository;
import com.example.project.repository.UserRepository;
import com.example.project.service.TrustService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DatabaseSeeder implements CommandLineRunner {

    private final UserRepository userRepo;
    private final PropertyRepository propertyRepo;
    private final PasswordEncoder encoder;
    private final TrustService trustService;

    public DatabaseSeeder(UserRepository userRepo, PropertyRepository propertyRepo, PasswordEncoder encoder, TrustService trustService) {
        this.userRepo = userRepo;
        this.propertyRepo = propertyRepo;
        this.encoder = encoder;
        this.trustService = trustService;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("=== Running NestIQ Database Seeder ===");

        if (userRepo.findByEmail("arjun@test.com").isEmpty()) {
            System.out.println("Seeding Customer: arjun@test.com");
            User customer = User.builder()
                    .name("Arjun Kumar")
                    .email("arjun@test.com")
                    .password(encoder.encode("password"))
                    .role(Role.CUSTOMER)
                    .phone("9876543210")
                    .verified(true)
                    .kycStatus("NONE")
                    .createdAt(LocalDateTime.now())
                    .build();
            userRepo.save(customer);
        }

        if (userRepo.findByEmail("sara@test.com").isEmpty()) {
            System.out.println("Seeding Agent: sara@test.com");
            User agent = User.builder()
                    .name("Sara John")
                    .email("sara@test.com")
                    .password(encoder.encode("password"))
                    .role(Role.AGENT)
                    .phone("9876543211")
                    .verified(true)
                    .kycStatus("VERIFIED")
                    .kycDocumentType("RERA_ID")
                    .kycDocumentNumber("TN/RERA/AG/2024/0129")
                    .createdAt(LocalDateTime.now())
                    .build();
            userRepo.save(agent);
        }

        if (userRepo.findByEmail("owner@test.com").isEmpty()) {
            System.out.println("Seeding Owner: owner@test.com");
            User owner = User.builder()
                    .name("Property Owner")
                    .email("owner@test.com")
                    .password(encoder.encode("password"))
                    .role(Role.OWNER)
                    .phone("9876543212")
                    .verified(true)
                    .kycStatus("VERIFIED")
                    .kycDocumentType("PAN")
                    .kycDocumentNumber("ABCDE1234F")
                    .createdAt(LocalDateTime.now())
                    .build();
            userRepo.save(owner);
        }

        if (userRepo.findByEmail("admin@nestiq.com").isEmpty()) {
            System.out.println("Seeding Admin: admin@nestiq.com");
            User admin = User.builder()
                    .name("NestIQ Admin")
                    .email("admin@nestiq.com")
                    .password(encoder.encode("admin123"))
                    .role(Role.ADMIN)
                    .phone("9876543213")
                    .verified(true)
                    .kycStatus("VERIFIED")
                    .createdAt(LocalDateTime.now())
                    .build();
            userRepo.save(admin);
        }

        if (propertyRepo.count() == 0) {
            System.out.println("=== Seeding Initial Property Listings ===");

            User agent = userRepo.findByEmail("sara@test.com").orElse(null);
            User owner = userRepo.findByEmail("owner@test.com").orElse(null);

            Property p1 = Property.builder()
                    .title("Spacious 3BHK Villa near ECR")
                    .description("Beautiful independent luxury villa located in the highly sought-after East Coast Road (ECR) premium corridor. Features private parking, fully landscaped garden, round-the-clock security surveillance, and top-tier modular fittings. Direct access to beach paths and seaside walkthroughs.")
                    .price(8500000.0)
                    .location("Injambakkam, ECR")
                    .city("Chennai")
                    .bhk(3)
                    .bathrooms(3)
                    .area(2400.0)
                    .propertyType("Villa")
                    .listingType("SALE")
                    .status("AVAILABLE")
                    .imageUrl("https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80")
                    .agent(agent)
                    .agentName(agent != null ? agent.getName() : "Sara John")
                    .agentPhone(agent != null ? agent.getPhone() : "9876543211")
                    .agentEmail(agent != null ? agent.getEmail() : "sara@test.com")
                    .agentVerified(true)
                    .agentRequestStatus("ASSIGNED")
                    .furnishing("Semi Furnished")
                    .facing("East")
                    .floor(0)
                    .totalFloors(2)
                    .approved(true)
                    .available(true)
                    .amenities("Parking, CCTV, Garden, Security, CCTV, Water Supply 24/7")
                    .createdAt(LocalDateTime.now())
                    .build();
            propertyRepo.save(p1);
            trustService.calculateAndSave(p1.getId());

            Property p2 = Property.builder()
                    .title("Cozy 2BHK Apartment in Saravanampatti")
                    .description("Premium fully-furnished apartment located inside IT park corridor of Saravanampatti. Ready-to-occupy state with high-speed internet, power backup, lifts, and security. Excellent ventilation and layout design.")
                    .price(22000.0)
                    .location("Keeranatham Road, Saravanampatti")
                    .city("Coimbatore")
                    .bhk(2)
                    .bathrooms(2)
                    .area(1100.0)
                    .propertyType("Apartment")
                    .listingType("RENT")
                    .status("AVAILABLE")
                    .imageUrl("https://images.unsplash.com/photo-1560448204-603b3fc33ddc?w=800&q=80")
                    .owner(owner)
                    .agentRequestStatus("SELF_SELL")
                    .furnishing("Fully Furnished")
                    .facing("North")
                    .floor(3)
                    .totalFloors(5)
                    .approved(true)
                    .available(true)
                    .amenities("Parking, Lift, CCTV, Power Backup, Water Supply 24/7")
                    .createdAt(LocalDateTime.now())
                    .build();
            propertyRepo.save(p2);
            trustService.calculateAndSave(p2.getId());

            Property p3 = Property.builder()
                    .title("Premium Commercial Space in Madurai")
                    .description("Unfurnished corporate office shell setup ready for fit-out. Features 100% power backup, high-speed lift access, separate washrooms, parking facility, and centralized CCTV network. Ideal for banks, IT offices, or retail outlets.")
                    .price(12000000.0)
                    .location("KK Nagar Road")
                    .city("Madurai")
                    .bhk(4)
                    .bathrooms(4)
                    .area(3500.0)
                    .propertyType("Commercial")
                    .listingType("SALE")
                    .status("AVAILABLE")
                    .imageUrl("https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80")
                    .agent(agent)
                    .agentName(agent != null ? agent.getName() : "Sara John")
                    .agentPhone(agent != null ? agent.getPhone() : "9876543211")
                    .agentEmail(agent != null ? agent.getEmail() : "sara@test.com")
                    .agentVerified(true)
                    .agentRequestStatus("ASSIGNED")
                    .furnishing("Unfurnished")
                    .facing("East")
                    .floor(1)
                    .totalFloors(3)
                    .approved(true)
                    .available(true)
                    .amenities("Parking, Lift, Power Backup, CCTV, Security")
                    .createdAt(LocalDateTime.now())
                    .build();
            propertyRepo.save(p3);
            trustService.calculateAndSave(p3.getId());
            
            System.out.println("=== Database Seeding Completed Successfully! ===");
        }
    }
}
