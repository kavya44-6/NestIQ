package com.example.project.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.project.dto.AiChatRequest;
import com.example.project.dto.AiChatResponse;
import com.example.project.dto.AiRecommendRequest;
import com.example.project.dto.AiRecommendResponse;
import com.example.project.dto.PropertyDTO;
import com.example.project.entity.Property;
import com.example.project.repository.PropertyRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
@Transactional
public class AiService {

    private final PropertyRepository propertyRepo;
    private final PropertyService    propertyService;
    private final GeminiService      geminiService;
    private final RuleBasedFallbackService fallbackService;
    private final EmbeddingService   embeddingService;
    private final TrustService       trustService;
    private final OkHttpClient       httpClient;
    private final ObjectMapper       objectMapper;

    @Value("${gemini.api.key:}")
    private String geminiKey;

    public AiService(PropertyRepository propertyRepo,
                     @Lazy PropertyService propertyService,
                     GeminiService geminiService,
                     RuleBasedFallbackService fallbackService,
                     EmbeddingService embeddingService,
                     TrustService trustService) {
        this.propertyRepo     = propertyRepo;
        this.propertyService  = propertyService;
        this.geminiService    = geminiService;
        this.fallbackService  = fallbackService;
        this.embeddingService = embeddingService;
        this.trustService     = trustService;
        this.httpClient       = new OkHttpClient();
        this.objectMapper     = new ObjectMapper();
    }

    public AiChatResponse chat(AiChatRequest req) {
        try {
            PropertyDTO property = propertyService.getPublicProperty(req.getPropertyId());
            if (geminiKey == null || geminiKey.isBlank()) {
                String reply = fallbackService.chat(property, req.getMessage());
                return new AiChatResponse(reply);
            }
            String reply = geminiService.chat(property, req.getMessage(), req.getHistory());
            return new AiChatResponse(reply);
        } catch (Exception e) {
            return new AiChatResponse(
                    "I'm unable to answer right now. Please use the Inquiry form to contact the agent.");
        }
    }

    public List<AiRecommendResponse> recommendProperties(AiRecommendRequest req) {
        List<Property> candidates = propertyRepo.findByApprovedTrue();
        if (candidates.isEmpty()) return Collections.emptyList();

        float[] queryVec = null;
        try {
            queryVec = embeddingService.generateEmbedding(req.getLifestyleNeeds() != null
                    ? req.getLifestyleNeeds() : "");
        } catch (Exception ignored) {}

        final float[] finalVec = queryVec;
        List<ScoredProperty> scored = candidates.stream()
                .map(p -> calculateScoredProperty(p, req, finalVec))
                .sorted(Comparator.comparingDouble(ScoredProperty::score).reversed())
                .limit(10)
                .collect(Collectors.toList());

        return scored.stream()
                .map(sp -> {
                    double normScore = Math.max(40.0, Math.min(99.0, sp.score()));
                    String reasoning = null;
                    if (geminiKey != null && !geminiKey.isBlank()) {
                        try {
                            String prompt = String.format(
                                "Generate exactly one paragraph (2-3 sentences) explaining why the property '%s' in %s (price ₹%,.0f) is recommended for a user with income ₹%,.0f/mo, family size %d, preferred city %s, and lifestyle needs: '%s'. Include Pros, Cons, and Nearby Facilities in your explanation.",
                                sp.property().getTitle(), sp.property().getCity(), sp.property().getPrice(),
                                req.getIncome(), req.getFamilySize(), req.getPreferredCity(), req.getLifestyleNeeds()
                            );
                            reasoning = callGeminiDirect(prompt);
                        } catch (Exception ignored) {}
                    }

                    if (reasoning == null || reasoning.isBlank()) {
                        reasoning = fallbackService.recommendReasoning(sp.property(), req, normScore);
                    }

                    return new AiRecommendResponse(
                            PropertyDTO.from(sp.property()),
                            Math.round(normScore * 10.0) / 10.0, // percent e.g. 85.5%
                            reasoning,
                            Math.round(sp.budgetFit() * 10.0) / 10.0,
                            Math.round(sp.familySizeFit() * 10.0) / 10.0,
                            Math.round(sp.cityMatch() * 10.0) / 10.0,
                            Math.round(sp.trustScoreContrib() * 10.0) / 10.0,
                            Math.round(sp.lifestyleMatch() * 10.0) / 10.0
                    );
                })
                .collect(Collectors.toList());
    }

    @Async
    public void generateAndStoreTrustExplanation(Long propertyId) {
        try {
            Property property = propertyRepo.findById(propertyId).orElse(null);
            if (property == null) return;

            Map<String, Object> breakdown = trustService.getBreakdown(propertyId);
            int duplicateCount = embeddingService.countDuplicates(property);

            String explanation = null;
            if (geminiKey != null && !geminiKey.isBlank()) {
                try {
                    String prompt = String.format(
                        "Analyze this property trust breakdown and write exactly 2-3 sentences explaining the trust rating. Be specific and actionable. " +
                        "Property: '%s'. Trust breakdown: Listing Quality %s/25, Agent Activity %s/20, Verification status %s/25, Pricing fraud signals %s/15, Total %s/100 (%s). Duplicate count: %d. Recommend actions for listers.",
                        property.getTitle(), breakdown.get("listingQuality"), breakdown.get("agentActivity"),
                        breakdown.get("documentVerification"), breakdown.get("fraudSignals"),
                        breakdown.get("totalScore"), breakdown.get("status"), duplicateCount
                    );
                    explanation = callGeminiDirect(prompt);
                } catch (Exception ignored) {}
            }

            if (explanation == null || explanation.isBlank()) {
                explanation = fallbackService.explainTrust(breakdown, duplicateCount, property.getTitle());
            }

            property.setAiExplanation(explanation);
            propertyRepo.save(property);
        } catch (Exception ignored) {
        }
    }

    public String getOrTriggerExplanation(Long propertyId) {
        Property property = propertyRepo.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found: " + propertyId));

        if (property.getAiExplanation() != null && !property.getAiExplanation().isBlank()) {
            return property.getAiExplanation();
        }

        generateAndStoreTrustExplanation(propertyId);
        return "Trust explanation is being generated. Please refresh in a moment.";
    }

    public Map<String, Object> fairPrice(Long propertyId) {
        Property p = propertyRepo.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found: " + propertyId));

        List<Property> similar = propertyRepo.findByCityAndBhkAndApprovedTrue(p.getCity(), p.getBhk());

        similar = similar.stream()
                .filter(s -> !s.getId().equals(p.getId()))
                .collect(Collectors.toList());

        if (similar.size() < 2) {
            return Map.of(
                    "listedPrice",    p.getPrice(),
                    "estimatedPrice", p.getPrice(),
                    "percentDiff",    0,
                    "verdict",        "Fairly Priced",
                    "color",          "#2d8653",
                    "sampleSize",     similar.size()
            );
        }

        double avg  = similar.stream().mapToDouble(Property::getPrice).average().orElse(p.getPrice());
        double diff = ((p.getPrice() - avg) / avg) * 100;

        String verdict, color;
        if      (diff < -10) { verdict = "Great Deal — " + (int) Math.abs(diff) + "% below market"; color = "#16a34a"; }
        else if (diff <  10) { verdict = "Fairly Priced";                                            color = "#2d8653"; }
        else if (diff <  20) { verdict = (int) diff + "% above market";                             color = "#b8952a"; }
        else                 { verdict = (int) diff + "% above market — negotiate";                 color = "#dc2626"; }

        Map<String, Object> result = new HashMap<>();
        result.put("listedPrice",    p.getPrice());
        result.put("estimatedPrice", Math.round(avg));
        result.put("percentDiff",    (int) diff);
        result.put("verdict",        verdict);
        result.put("color",          color);
        result.put("sampleSize",     similar.size());
        return result;
    }

    public Map<String, Object> trustBreakdown(Long propertyId) {
        return trustService.getBreakdown(propertyId);
    }

    public String generateDescription(PropertyDTO details) {
        if (geminiKey == null || geminiKey.isBlank()) {
            return fallbackDescription(details);
        }

        try {
            String title = details.getTitle();
            String city = details.getCity();
            String address = details.getAddress() != null ? details.getAddress() : details.getLocation();
            Integer bedrooms = details.getBedrooms() != null ? details.getBedrooms() : details.getBhk();
            Double area = details.getArea();
            String propertyType = details.getPropertyType();
            String listingType = details.getListingType();
            String furnishing = details.getFurnishing();

            String prompt = String.format(
                "Write a professional 3-sentence property description for a Tamil Nadu real estate listing.\n" +
                "Use ONLY the provided details. Tone: factual, professional.\n" +
                "Title: %s, City: %s, Location: %s, BHK: %s, Area: %s sqft, Type: %s, Listing: %s, Furnishing: %s.\n" +
                "Write exactly 3 sentences. No bullet points.",
                title, city, address, bedrooms, area, propertyType, listingType, furnishing
            );

            String responseText = callGeminiDirect(prompt);
            if (responseText != null && !responseText.isBlank()) {
                return responseText;
            }
        } catch (Exception e) {
        }
        return fallbackDescription(details);
    }

    public Map<String, Object> estimatePrice(PropertyDTO details) {
        String city = details.getCity();
        Integer bhk = details.getBedrooms() != null ? details.getBedrooms() : details.getBhk();
        Double area = details.getArea() != null ? details.getArea() : 1000.0;
        String listingType = details.getListingType() != null ? details.getListingType() : "RENT";
        String furnishing = details.getFurnishing();

        double baseRate = getCityRate(city);
        double bhkNum = bhk != null ? bhk : 2;
        double areaNum = area != null ? area : 1000.0;

        double estimated = baseRate * areaNum * (0.8 + bhkNum * 0.1);
        if ("Fully Furnished".equalsIgnoreCase(furnishing)) {
            estimated *= 1.25;
        } else if ("Semi Furnished".equalsIgnoreCase(furnishing)) {
            estimated *= 1.10;
        }

        if ("SALE".equalsIgnoreCase(listingType)) {
            estimated = estimated * 12.0 * 80.0;
        }

        long min = Math.round(estimated * 0.90);
        long max = Math.round(estimated * 1.15);

        String explanation = null;
        if (geminiKey != null && !geminiKey.isBlank()) {
            try {
                String rentOrSale = "RENT".equalsIgnoreCase(listingType) ? " per month for rent" : " for sale";
                String prompt = String.format(
                    "Write exactly one sentence explaining why a %dBHK %.0f sqft property in %s, Tamil Nadu would be priced between " +
                    "₹%,d and ₹%,d%s. Be factual and specific to the Tamil Nadu real estate market. No made-up data.",
                    bhk, area, city, min, max, rentOrSale
                );
                explanation = callGeminiDirect(prompt);
            } catch (Exception ignored) {}
        }

        if (explanation == null || explanation.isBlank()) {
            explanation = fallbackService.estimatePriceExplanation(details, baseRate, min, max);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("estimatedMin", min);
        response.put("estimatedMax", max);
        response.put("explanation", explanation);
        response.put("city", city);
        response.put("listingType", listingType);

        Map<String, Object> breakdown = new HashMap<>();
        breakdown.put("baseRate", baseRate);
        breakdown.put("areaContribution", baseRate * areaNum);
        breakdown.put("bhkFactor", 0.8 + bhkNum * 0.1);
        breakdown.put("furnishingMultiplier", "Fully Furnished".equalsIgnoreCase(furnishing) ? 1.25 : ("Semi Furnished".equalsIgnoreCase(furnishing) ? 1.10 : 1.0));
        breakdown.put("saleMultiplier", "SALE".equalsIgnoreCase(listingType) ? 12.0 * 80.0 : 1.0);
        breakdown.put("baseEstimate", baseRate * areaNum * (0.8 + bhkNum * 0.1));
        response.put("breakdown", breakdown);

        return response;
    }

    /**
     * Contextual Market Analysis for Price Trends page.
     */
    public Map<String, Object> getMarketAnalysis(String city) {
        double baseRate = getCityRate(city);
        double saleAvg = baseRate * 1000.0 * 12.0 * 80.0 / 1000.0; // sale price per sqft
        double rentAvg = baseRate; // rent per sqft per month

        String app = "6.8%";
        String liquidity = "Moderate";
        String demand = "Stable";
        if ("Chennai".equalsIgnoreCase(city)) {
            app = "8.4%"; liquidity = "High"; demand = "High";
        } else if ("Coimbatore".equalsIgnoreCase(city)) {
            app = "7.2%"; liquidity = "High"; demand = "Moderate";
        }

        double finalSaleAvg = saleAvg;
        double finalRentAvg = rentAvg;
        List<Property> active = propertyRepo.findByCityAndApprovedTrue(city).stream()
                .filter(p -> !"SOLD".equalsIgnoreCase(p.getStatus()) && !"RENTED".equalsIgnoreCase(p.getStatus()))
                .toList();

        if (!active.isEmpty()) {
            double saleSum = 0; int saleCnt = 0;
            double rentSum = 0; int rentCnt = 0;
            for (Property p : active) {
                double area = p.getArea() != null && p.getArea() > 0 ? p.getArea() : 1000.0;
                if ("SALE".equalsIgnoreCase(p.getListingType())) {
                    saleSum += (p.getPrice() / area);
                    saleCnt++;
                } else {
                    rentSum += (p.getPrice() / area);
                    rentCnt++;
                }
            }
            if (saleCnt > 0) saleAvg = saleSum / saleCnt;
            if (rentCnt > 0) rentAvg = rentSum / rentCnt;
        }

        double diffSalePercent = ((saleAvg - finalSaleAvg) / finalSaleAvg) * 100;
        double diffRentPercent = ((rentAvg - finalRentAvg) / finalRentAvg) * 100;

        String buyerRec = "Fair pricing detected. Focus on negotiating details and target high trust score properties.";
        String sellerRec = "Stable market value. Highlight property amenities and complete listing detail fields for faster closing.";
        String investmentOutlook = "Stable rental yields play. Accumulate assets in high appreciation corridors.";

        if (diffSalePercent > 10) {
            buyerRec = "Asking rates are premium. Look for motivated sellers or properties with active RERA verification tags.";
            sellerRec = "Premium market phase. Capitalize on elevated pricing indices. List details completely now.";
            investmentOutlook = "Consolidate. Yields are compressed. Focus strictly on premium commercial plots.";
        } else if (diffSalePercent < -10) {
            buyerRec = "Attractive valuation. Current listings are undervalued. Strong buy signal for long-term appreciation.";
            sellerRec = "Hold assets. Market price is depressed. Defer selling until baseline demand levels return.";
            investmentOutlook = "Highly Bullish. Undervalued catalog provides a strong margin of safety.";
        }

        String aiAnalysis = null;
        if (geminiKey != null && !geminiKey.isBlank()) {
            try {
                String prompt = String.format(
                    "Write exactly 2 sentences analyzing the real estate market in %s, Tamil Nadu. " +
                    "Avg Sale: ₹%,.0f/sqft, Avg Rent: ₹%,.0f/sqft. Appreciation: %s/year. Demand: %s. State the outlook for buyers and investors.",
                    city, saleAvg, rentAvg, app, demand
                );
                aiAnalysis = callGeminiDirect(prompt);
            } catch (Exception ignored) {}
        }

        if (aiAnalysis == null || aiAnalysis.isBlank()) {
            aiAnalysis = String.format(
                "The real estate market in %s exhibits a %s demand profile with a solid %.1f%% annual capital appreciation rate. " +
                "Average sale prices stand at ₹%,.0f/sqft and rentals at ₹%,.0f/sqft/mo, showing high investment potential.",
                city, demand, Double.parseDouble(app.replace("%","")), saleAvg, rentAvg
            );
        }

        Map<String, Object> res = new HashMap<>();
        res.put("city", city);
        res.put("avgSalePriceSqft", Math.round(saleAvg));
        res.put("avgRentPriceSqft", Math.round(rentAvg));
        res.put("appreciationRate", app);
        res.put("liquidityScore", liquidity);
        res.put("demandQuotient", demand);
        res.put("diffSalePercent", Math.round(diffSalePercent));
        res.put("diffRentPercent", Math.round(diffRentPercent));
        res.put("buyerRecommendation", buyerRec);
        res.put("sellerRecommendation", sellerRec);
        res.put("investmentOutlook", investmentOutlook);
        res.put("aiMarketAnalysis", aiAnalysis);
        return res;
    }

    private double getCityRate(String city) {
        if (city == null) return 12.0;
        switch (city) {
            case "Chennai": return 22.0;
            case "Coimbatore": return 15.0;
            case "Madurai": return 12.0;
            case "Tiruchirappalli": return 11.0;
            case "Salem": return 10.0;
            case "Tiruppur": return 10.5;
            case "Vellore": return 9.5;
            default: return 12.0;
        }
    }

    private String fallbackDescription(PropertyDTO details) {
        Integer bhk = details.getBedrooms() != null ? details.getBedrooms() : details.getBhk();
        String bhkStr = bhk != null ? bhk.toString() : "2";
        String type = details.getPropertyType() != null ? details.getPropertyType() : "Apartment";
        String area = details.getArea() != null ? details.getArea().toString() : "1000";
        String listing = details.getListingType() != null ? details.getListingType().toLowerCase() : "rent";
        String city = details.getCity() != null ? details.getCity() : "Tamil Nadu";
        String location = details.getLocation() != null ? details.getLocation() : city;
        String furnishing = details.getFurnishing();
        String furnStr = (furnishing != null && !furnishing.isBlank()) ? " " + furnishing + "." : "";

        return String.format(
            "Presenting a premium %s BHK %s located in the prime area of %s, %s. Spanning a built-up area of %s sqft, this %s property offers excellent utility. Currently available for %s, contact the agent for quick site visits.",
            bhkStr, type, location, city, area, furnStr, listing
        );
    }

    private String callGeminiDirect(String prompt) throws Exception {
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + geminiKey;
        
        Map<String, Object> textPart = Map.of("text", prompt);
        Map<String, Object> content = Map.of(
            "role", "user",
            "parts", List.of(textPart)
        );
        
        Map<String, Object> genConfig = Map.of("maxOutputTokens", 200, "temperature", 0.7);
        
        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("contents", List.of(content));
        bodyMap.put("generationConfig", genConfig);

        String jsonBody = objectMapper.writeValueAsString(bodyMap);
        
        RequestBody body = RequestBody.create(jsonBody, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
                
        try (Response response = httpClient.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();
                JsonNode root = objectMapper.readTree(responseBody);
                return root.path("candidates").get(0)
                        .path("content").path("parts").get(0)
                        .path("text").asText().trim();
            }
        }
        return null;
    }

    private ScoredProperty calculateScoredProperty(Property p, AiRecommendRequest req, float[] queryVec) {
        double budgetFit = 12.5;
        if (req.getIncome() != null && p.getPrice() != null) {
            double monthlyIncome = req.getIncome();
            double maxBudget = monthlyIncome * 0.4;
            double price = p.getPrice();
            if (price <= maxBudget) {
                double ratio = price / maxBudget;
                budgetFit = 15.0 + 10.0 * (1.0 - ratio);
            } else {
                double ratio = maxBudget / price;
                budgetFit = Math.max(0.0, 15.0 * ratio);
            }
        }

        double familySizeFit = 10.0;
        if (req.getFamilySize() != null && p.getBhk() != null) {
            int idealBhk = req.getFamilySize() <= 2 ? 1 : req.getFamilySize() <= 4 ? 2 : 3;
            int diff = Math.abs(p.getBhk() - idealBhk);
            familySizeFit = Math.max(0.0, 20.0 - diff * 10.0);
        }

        double cityMatch = 0.0;
        if (req.getPreferredCity() != null && p.getCity() != null) {
            if (p.getCity().equalsIgnoreCase(req.getPreferredCity())) {
                cityMatch = 15.0;
            } else {
                cityMatch = 0.0;
            }
        } else {
            cityMatch = 7.5;
        }

        double trustScoreContrib = 10.0;
        if (p.getTrustScore() != null) {
            trustScoreContrib = p.getTrustScore() * 0.20;
        }

        double lifestyleMatch = 10.0;
        if (queryVec != null && queryVec.length > 0) {
            float[] propVec = embeddingService.getStoredEmbedding(p.getId());
            if (propVec != null) {
                double similarity = embeddingService.cosineSimilarity(queryVec, propVec);
                lifestyleMatch = Math.max(0.0, Math.min(20.0, similarity * 20.0));
            }
        } else if (req.getLifestyleNeeds() != null && !req.getLifestyleNeeds().isBlank()) {
            String needs = req.getLifestyleNeeds().toLowerCase();
            String body = ((p.getTitle() != null ? p.getTitle() : "") + " " +
                           (p.getDescription() != null ? p.getDescription() : "") + " " +
                           (p.getAmenities() != null ? p.getAmenities() : "")).toLowerCase();
            String[] keywords = needs.split("[,\\s]+");
            int hits = 0;
            for (String kw : keywords) {
                if (kw.length() > 3 && body.contains(kw)) {
                    hits++;
                }
            }
            lifestyleMatch = Math.min(20.0, 10.0 + hits * 5.0);
        }

        double score = budgetFit + familySizeFit + cityMatch + trustScoreContrib + lifestyleMatch;
        return new ScoredProperty(p, score, budgetFit, familySizeFit, cityMatch, trustScoreContrib, lifestyleMatch);
    }

    private record ScoredProperty(
        Property property,
        double score,
        double budgetFit,
        double familySizeFit,
        double cityMatch,
        double trustScoreContrib,
        double lifestyleMatch
    ) {}
}
